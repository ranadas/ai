from anthropic import Anthropic

from .base import Extractor, ExtractorRegistry, LLMExtractor
from .document_extractors import (
    BankStatementExtractor,
    InvoiceExtractor,
    NationalIdExtractor,
    PassportExtractor,
)


def build_default_registry(client: Anthropic, model: str = "claude-sonnet-4-6") -> ExtractorRegistry:
    """Wires up every known extractor. Single place to touch when onboarding
    a new document type."""
    registry = ExtractorRegistry()
    registry.register(InvoiceExtractor(client, model))
    registry.register(PassportExtractor(client, model))
    registry.register(NationalIdExtractor(client, model))
    registry.register(BankStatementExtractor(client, model))
    return registry


__all__ = [
    "Extractor",
    "ExtractorRegistry",
    "LLMExtractor",
    "build_default_registry",
]
