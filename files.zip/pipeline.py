"""Pipeline orchestrator.

Everything that decides WHAT HAPPENS NEXT lives here in plain Python:
confidence thresholds, routing targets, review-queue triggers. The LLM only
ever answers "what is this" and "what does it say" — never "what should I do
about it." That separation is the whole point.
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass

from classifier import DocumentClassifier
from extractors.base import ExtractorRegistry
from models import (
    DocumentType,
    ExtractionStatus,
    PipelineOutcome,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PipelineConfig:
    classification_confidence_threshold: float = 0.75
    review_queue_route: str = "manual_review_queue"


class DocumentPipeline:
    """Ingest -> classify -> gate -> extract -> gate -> outcome.

    Each stage is a discrete, independently testable step. The public entry
    point (process) never raises on a low-confidence or ambiguous document —
    it routes it. Exceptions are reserved for genuine infra failures.
    """

    def __init__(
        self,
        classifier: DocumentClassifier,
        extractor_registry: ExtractorRegistry,
        config: PipelineConfig | None = None,
    ) -> None:
        self._classifier = classifier
        self._registry = extractor_registry
        self._config = config or PipelineConfig()

    def process(self, image_bytes: bytes, media_type: str, document_id: str | None = None) -> PipelineOutcome:
        document_id = document_id or str(uuid.uuid4())

        classification = self._classifier.classify(image_bytes, media_type)

        if not self._passes_classification_gate(classification):
            return self._to_review(document_id, classification, reason="low_confidence_or_unknown")

        extractor = self._registry.get(classification.document_type)
        if extractor is None:
            # Classified successfully, but we have no extractor for this type yet.
            return self._to_review(document_id, classification, reason="no_extractor_registered")

        extraction = extractor.extract(image_bytes, media_type)
        route = self._route_for(classification.document_type, extraction)

        outcome = PipelineOutcome(
            document_id=document_id,
            classification=classification,
            extraction=extraction,
            routed_to=route,
        )
        logger.info(
            "document_id=%s type=%s route=%s status=%s",
            document_id,
            classification.document_type,
            route,
            extraction.status,
        )
        return outcome

    def _passes_classification_gate(self, classification) -> bool:
        if classification.document_type == DocumentType.UNKNOWN:
            return False
        return classification.confidence >= self._config.classification_confidence_threshold

    def _route_for(self, document_type: DocumentType, extraction) -> str:
        if extraction.status in (ExtractionStatus.PARTIAL, ExtractionStatus.FAILED):
            return self._config.review_queue_route
        return f"{document_type.value}_pipeline"

    def _to_review(self, document_id: str, classification, reason: str) -> PipelineOutcome:
        logger.warning("document_id=%s routed_to_review reason=%s", document_id, reason)
        return PipelineOutcome(
            document_id=document_id,
            classification=classification,
            extraction=None,
            routed_to=self._config.review_queue_route,
        )
