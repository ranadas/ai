"""Extractor strategy pattern.

Adding support for a new document type means writing one new Extractor class
and registering it — nothing else in the pipeline changes. This is the same
shape as your invoice pipeline's per-stage handlers: swap the implementation,
keep the contract fixed.
"""
from __future__ import annotations

import base64
from typing import ClassVar, Protocol

from anthropic import Anthropic
from pydantic import BaseModel

from models import DocumentType, ExtractionResult, ExtractionStatus


class Extractor(Protocol):
    """Contract every document-type extractor must satisfy."""

    document_type: ClassVar[DocumentType]
    schema: ClassVar[type[BaseModel]]
    required_fields: ClassVar[tuple[str, ...]]

    def extract(self, image_bytes: bytes, media_type: str) -> ExtractionResult: ...


class LLMExtractor:
    """Base implementation: one structured-output call per document type,
    followed by a deterministic completeness check.

    Subclasses only need to set the four class attributes below — the
    extract() logic (call model, validate, check required fields) is shared.
    """

    document_type: ClassVar[DocumentType]
    schema: ClassVar[type[BaseModel]]
    required_fields: ClassVar[tuple[str, ...]] = ()
    system_prompt: ClassVar[str] = "Extract structured data from this document image."

    def __init__(self, client: Anthropic, model: str = "claude-sonnet-4-6") -> None:
        self._client = client
        self._model = model

    def extract(self, image_bytes: bytes, media_type: str) -> ExtractionResult:
        tool = {
            "name": "extract_fields",
            "description": f"Extract structured fields for a {self.document_type.value}.",
            "input_schema": self.schema.model_json_schema(),
        }
        response = self._client.messages.create(
            model=self._model,
            max_tokens=1024,
            system=self.system_prompt,
            tools=[tool],
            tool_choice={"type": "tool", "name": "extract_fields"},
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": base64.b64encode(image_bytes).decode(),
                            },
                        },
                        {"type": "text", "text": "Extract the fields from this document."},
                    ],
                }
            ],
        )
        tool_use = next(b for b in response.content if b.type == "tool_use")
        parsed = self.schema(**tool_use.input)

        missing = self._missing_required_fields(parsed)
        status = ExtractionStatus.OK if not missing else ExtractionStatus.PARTIAL

        return ExtractionResult(
            document_type=self.document_type,
            status=status,
            data=parsed.model_dump(mode="json"),
            missing_required_fields=missing,
        )

    def _missing_required_fields(self, parsed: BaseModel) -> list[str]:
        return [f for f in self.required_fields if getattr(parsed, f, None) is None]


class ExtractorRegistry:
    """Maps DocumentType -> Extractor instance. Deterministic dispatch, no LLM
    involved in routing itself."""

    def __init__(self) -> None:
        self._extractors: dict[DocumentType, Extractor] = {}

    def register(self, extractor: Extractor) -> None:
        self._extractors[extractor.document_type] = extractor

    def get(self, document_type: DocumentType) -> Extractor | None:
        return self._extractors.get(document_type)
