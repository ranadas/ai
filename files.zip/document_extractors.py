"""Concrete extractor implementations. Each is a thin declaration over the
shared LLMExtractor — schema + required fields + a type-specific prompt."""
from __future__ import annotations

from typing import ClassVar

from ..models import (
    BankStatementData,
    DocumentType,
    InvoiceData,
    NationalIdData,
    PassportData,
)
from .base import LLMExtractor


class InvoiceExtractor(LLMExtractor):
    document_type: ClassVar[DocumentType] = DocumentType.INVOICE
    schema: ClassVar[type] = InvoiceData
    required_fields: ClassVar[tuple[str, ...]] = (
        "invoice_number",
        "total_amount",
        "currency",
    )
    system_prompt: ClassVar[str] = (
        "Extract invoice fields exactly as printed. Do not infer or normalize "
        "amounts across currencies. If a field is not present, omit it rather "
        "than guessing."
    )


class PassportExtractor(LLMExtractor):
    document_type: ClassVar[DocumentType] = DocumentType.PASSPORT
    schema: ClassVar[type] = PassportData
    required_fields: ClassVar[tuple[str, ...]] = (
        "document_number",
        "surname",
        "date_of_expiry",
    )
    system_prompt: ClassVar[str] = (
        "Extract passport fields, preferring the Machine Readable Zone (MRZ) "
        "over the visual zone when both are present, as the MRZ is more "
        "reliably read. This document contains PII — extract only the "
        "requested fields, nothing else."
    )


class NationalIdExtractor(LLMExtractor):
    document_type: ClassVar[DocumentType] = DocumentType.NATIONAL_ID
    schema: ClassVar[type] = NationalIdData
    required_fields: ClassVar[tuple[str, ...]] = ("document_number", "full_name")
    system_prompt: ClassVar[str] = (
        "Extract national ID card fields. This document contains PII — "
        "extract only the requested fields, nothing else."
    )


class BankStatementExtractor(LLMExtractor):
    document_type: ClassVar[DocumentType] = DocumentType.BANK_STATEMENT
    schema: ClassVar[type] = BankStatementData
    required_fields: ClassVar[tuple[str, ...]] = (
        "account_holder",
        "closing_balance",
        "currency",
    )
    system_prompt: ClassVar[str] = (
        "Extract bank statement summary fields. Mask all but the last 4 "
        "digits of any account number you extract."
    )
