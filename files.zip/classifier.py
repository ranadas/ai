"""Vision-LLM-backed document classification.

Design principle: the LLM call is the ONLY non-deterministic component in this
module. Everything else (confidence gating, routing) lives in plain Python so
it's unit-testable without mocking the model.
"""
from __future__ import annotations

import base64
import logging

from anthropic import Anthropic

from models import ClassificationResult

logger = logging.getLogger(__name__)

CLASSIFICATION_TOOL = {
    "name": "classify_document",
    "description": "Classify a document image into a known document type.",
    "input_schema": ClassificationResult.model_json_schema(),
}

_SYSTEM_PROMPT = (
    "You are a document classification engine. You will be shown an image of "
    "a single document page. Classify it into exactly one of the supported "
    "document types. If the document does not clearly match a known type, or "
    "the image is unreadable/cropped/ambiguous, return 'unknown' with a low "
    "confidence rather than guessing. Base confidence on visual clarity and "
    "presence of type-defining features (e.g. MRZ lines for passports, "
    "line-item tables for invoices) — not on how plausible a guess feels."
)


class DocumentClassifier:
    """Thin wrapper around a single classification call."""

    def __init__(self, client: Anthropic, model: str = "claude-sonnet-4-6") -> None:
        self._client = client
        self._model = model

    def classify(self, image_bytes: bytes, media_type: str) -> ClassificationResult:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=512,
            system=_SYSTEM_PROMPT,
            tools=[CLASSIFICATION_TOOL],
            tool_choice={"type": "tool", "name": "classify_document"},
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": base64.b64encode(image_bytes).decode(),
                            },
                        },
                        {"type": "text", "text": "Classify this document."},
                    ],
                }
            ],
        )
        tool_use = next(b for b in response.content if b.type == "tool_use")
        result = ClassificationResult(**tool_use.input)
        logger.info(
            "classified document_type=%s confidence=%.2f",
            result.document_type,
            result.confidence,
        )
        return result
