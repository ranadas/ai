"""Vision/text-LLM-backed document classification.

Handles both content kinds produced by ingestion: extracted text (born-digital
PDFs) and page images (scanned documents). The LLM call is the only
non-deterministic component in this module.
"""
from __future__ import annotations

import logging

from anthropic import Anthropic

from .content import build_content_blocks
from .models import ClassificationResult, IngestedDocument

logger = logging.getLogger(__name__)

CLASSIFICATION_TOOL = {
    "name": "classify_document",
    "description": "Classify a document into a known document type.",
    "input_schema": ClassificationResult.model_json_schema(),
}

_SYSTEM_PROMPT = (
    "You are a document classification engine. You will be shown either the "
    "extracted text of a document or images of its pages, depending on how "
    "it was scanned. Classify it into exactly one of the supported document "
    "types. If the content does not clearly match a known type, or is "
    "unreadable/ambiguous, return 'unknown' with a low confidence rather "
    "than guessing. Base confidence on clarity and presence of "
    "type-defining features (e.g. MRZ lines for passports, line-item tables "
    "and invoice numbers for invoices) — not on how plausible a guess feels."
)

_INSTRUCTION = "Classify this document."


class DocumentClassifier:
    def __init__(self, client: Anthropic, model: str = "claude-sonnet-4-6") -> None:
        self._client = client
        self._model = model

    def classify(self, document: IngestedDocument) -> ClassificationResult:
        content = build_content_blocks(document, _INSTRUCTION)

        response = self._client.messages.create(
            model=self._model,
            max_tokens=512,
            system=_SYSTEM_PROMPT,
            tools=[CLASSIFICATION_TOOL],
            tool_choice={"type": "tool", "name": "classify_document"},
            messages=[{"role": "user", "content": content}],
        )
        tool_use = next(b for b in response.content if b.type == "tool_use")
        result = ClassificationResult(**tool_use.input)
        logger.info(
            "classified content_kind=%s document_type=%s confidence=%.2f",
            document.kind,
            result.document_type,
            result.confidence,
        )
        return result
