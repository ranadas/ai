"""Example wiring / composition root.

Run as a module from the directory containing doc_pipeline/, e.g.:

    python -m doc_pipeline.main

Running it as a loose script (python doc_pipeline/main.py) will NOT work
correctly for a package that uses relative imports — that's issue #2 from
the previous version. `-m` is the fix: it runs the file as part of the
package rather than as a standalone script.
"""
import logging

from anthropic import Anthropic

from .classifier import DocumentClassifier
from .extractors import build_default_registry
from .ingestion import ingest
from .pipeline import DocumentPipeline, PipelineConfig

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


def main() -> None:
    client = Anthropic()  # reads ANTHROPIC_API_KEY from env

    classifier = DocumentClassifier(client)
    extractor_registry = build_default_registry(client)
    pipeline = DocumentPipeline(
        classifier,
        extractor_registry,
        config=PipelineConfig(classification_confidence_threshold=0.75),
    )

    # Case 1: born-digital invoice PDF -> ingestion extracts text, no vision
    # call needed for classification or extraction.
    invoice_bytes = open("sample_invoice.pdf", "rb").read()
    invoice_doc = ingest(invoice_bytes, filename="sample_invoice.pdf")
    invoice_outcome = pipeline.process(invoice_doc)
    print(invoice_outcome.model_dump_json(indent=2))

    # Case 2: scanned passport PDF -> ingestion detects no text layer,
    # rasterizes pages, routes to the vision path automatically.
    passport_bytes = open("sample_passport.pdf", "rb").read()
    passport_doc = ingest(passport_bytes, filename="sample_passport.pdf")
    passport_outcome = pipeline.process(passport_doc)
    print(passport_outcome.model_dump_json(indent=2))


if __name__ == "__main__":
    main()
