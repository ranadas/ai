"""Example wiring. In a Spring-Boot-style deployment, this composition root
maps to your @Configuration class — the only place concrete instances get
constructed."""
import logging
from pathlib import Path

from anthropic import Anthropic

from classifier import DocumentClassifier
from extractors import build_default_registry
from pipeline import DocumentPipeline, PipelineConfig

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


def main() -> None:
    client = Anthropic()  # reads ANTHROPIC_API_KEY from env

    classifier = DocumentClassifier(client)
    extractor_registry = build_default_registry(client)
    pipeline = DocumentPipeline(
        classifier,
        extractor_registry,
        config=PipelineConfig(classification_confidence_threshold=0.75),
    )

    image_path = Path("sample_invoice.jpg")
    image_bytes = image_path.read_bytes()

    outcome = pipeline.process(image_bytes, media_type="image/jpeg")

    print(outcome.model_dump_json(indent=2))


if __name__ == "__main__":
    main()
