"""Domain models for the document classification & extraction pipeline."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class DocumentType(str, Enum):
    INVOICE = "invoice"
    PASSPORT = "passport"
    NATIONAL_ID = "national_id"
    BANK_STATEMENT = "bank_statement"
    UNKNOWN = "unknown"


class ContentKind(str, Enum):
    """How a document's content is represented after ingestion.

    TEXT  — born-digital source (e.g. an invoice PDF with a real text layer).
            We extract the text directly; no OCR/vision call needed.
    IMAGE — no usable text layer (e.g. a scanned passport/ID). Rasterized
            page images are sent to the vision model instead.
    """

    TEXT = "text"
    IMAGE = "image"


@dataclass(frozen=True)
class IngestedDocument:
    """Normalized output of the ingestion stage. Plain dataclass, not a
    Pydantic model — it carries raw image bytes, which don't belong in an
    API-facing schema."""

    kind: ContentKind
    text: Optional[str] = None
    page_images: list[bytes] = field(default_factory=list)
    image_media_type: str = "image/png"


class ClassificationResult(BaseModel):
    """Output of the classification stage. Treated as a hypothesis, not fact."""

    document_type: DocumentType
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str


class ExtractionStatus(str, Enum):
    OK = "ok"
    PARTIAL = "partial"          # extracted but some required fields missing
    FAILED = "failed"


class InvoiceData(BaseModel):
    invoice_number: Optional[str] = None
    invoice_date: Optional[date] = None
    vendor_name: Optional[str] = None
    total_amount: Optional[float] = None
    currency: Optional[str] = None
    line_item_count: Optional[int] = None


class PassportData(BaseModel):
    document_number: Optional[str] = None
    surname: Optional[str] = None
    given_names: Optional[str] = None
    nationality: Optional[str] = None
    date_of_birth: Optional[date] = None
    date_of_expiry: Optional[date] = None
    issuing_country: Optional[str] = None


class NationalIdData(BaseModel):
    document_number: Optional[str] = None
    full_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    date_of_expiry: Optional[date] = None
    issuing_country: Optional[str] = None


class BankStatementData(BaseModel):
    account_holder: Optional[str] = None
    account_number_masked: Optional[str] = None
    statement_period_start: Optional[date] = None
    statement_period_end: Optional[date] = None
    closing_balance: Optional[float] = None
    currency: Optional[str] = None


class ExtractionResult(BaseModel):
    document_type: DocumentType
    status: ExtractionStatus
    data: dict = Field(default_factory=dict)
    missing_required_fields: list[str] = Field(default_factory=list)


class PipelineOutcome(BaseModel):
    """Audit-trail record for one document run through the pipeline."""

    document_id: str
    source_content_kind: ContentKind
    classification: ClassificationResult
    extraction: Optional[ExtractionResult] = None
    routed_to: str
