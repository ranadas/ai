"""Domain models for the document classification & extraction pipeline.

All schemas are Pydantic models so they double as:
  1. The JSON schema handed to the LLM as a tool definition (structured output)
  2. The validation boundary between the LLM's output and the rest of the system
"""
from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class DocumentType(str, Enum):
    INVOICE = "invoice"
    PASSPORT = "passport"
    NATIONAL_ID = "national_id"
    BANK_STATEMENT = "bank_statement"
    UNKNOWN = "unknown"


class ClassificationResult(BaseModel):
    """Output of the classification stage. Treated as a hypothesis, not fact."""

    document_type: DocumentType
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str


class ExtractionStatus(str, Enum):
    OK = "ok"
    PARTIAL = "partial"          # extracted but some required fields missing
    LOW_CONFIDENCE = "low_confidence"
    FAILED = "failed"


class InvoiceData(BaseModel):
    invoice_number: Optional[str] = None
    invoice_date: Optional[date] = None
    vendor_name: Optional[str] = None
    total_amount: Optional[float] = None
    currency: Optional[str] = None
    line_item_count: Optional[int] = None


class PassportData(BaseModel):
    document_number: Optional[str] = None
    surname: Optional[str] = None
    given_names: Optional[str] = None
    nationality: Optional[str] = None
    date_of_birth: Optional[date] = None
    date_of_expiry: Optional[date] = None
    issuing_country: Optional[str] = None


class NationalIdData(BaseModel):
    document_number: Optional[str] = None
    full_name: Optional[str] = None
    date_of_birth: Optional[date] = None
    date_of_expiry: Optional[date] = None
    issuing_country: Optional[str] = None


class BankStatementData(BaseModel):
    account_holder: Optional[str] = None
    account_number_masked: Optional[str] = None
    statement_period_start: Optional[date] = None
    statement_period_end: Optional[date] = None
    closing_balance: Optional[float] = None
    currency: Optional[str] = None


class ExtractionResult(BaseModel):
    """Wraps extracted data with the metadata needed for a downstream audit trail."""

    document_type: DocumentType
    status: ExtractionStatus
    data: dict = Field(default_factory=dict)  # validated model, dumped to dict
    missing_required_fields: list[str] = Field(default_factory=list)
    raw_confidence: float = Field(ge=0.0, le=1.0, default=0.0)


class PipelineOutcome(BaseModel):
    """Final record for a single document run through the pipeline. This is the
    audit-trail artifact — log/persist this, not intermediate LLM responses."""

    document_id: str
    classification: ClassificationResult
    extraction: Optional[ExtractionResult] = None
    routed_to: str
