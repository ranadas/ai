"""In-memory schema catalog + sample data for the NL-to-SQL agent.

This module stands in for a real connection to SQL Server. It keeps two
things in an in-memory SQLite database:

1. A ``schema_catalog`` table holding the *canonical* T-SQL (SQL Server)
   ``CREATE TABLE`` DDL for every table the agent is allowed to know about.
   This is the text the LLM is grounded on when it writes SQL.
2. Lightweight mirror tables (translated to SQLite-compatible types) with a
   handful of seed rows, so the agent can optionally preview sample data
   while composing a query.

Nothing here is ever executed against SQL Server -- the agent only emits
T-SQL text. The generated SQL is expected to be run by a human/DBA against
the real SQL Server instance.
"""

from __future__ import annotations

import datetime
import sqlite3
from dataclasses import dataclass


@dataclass(frozen=True)
class TableDef:
    name: str
    comment: str
    ddl: str  # canonical SQL Server (T-SQL) DDL
    sqlite_ddl: str  # translated DDL used only for the in-memory preview mirror


TABLES: list[TableDef] = [
    TableDef(
        name="dbo.Departments",
        comment="Company departments that users belong to.",
        ddl="""\
CREATE TABLE dbo.Departments (
    DepartmentId    INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    DepartmentName  NVARCHAR(100)     NOT NULL UNIQUE
);""",
        sqlite_ddl="""\
CREATE TABLE Departments (
    DepartmentId    INTEGER PRIMARY KEY AUTOINCREMENT,
    DepartmentName  TEXT NOT NULL UNIQUE
);""",
    ),
    TableDef(
        name="dbo.Users",
        comment="Application user accounts.",
        ddl="""\
CREATE TABLE dbo.Users (
    UserId        INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    UserName      NVARCHAR(100)     NOT NULL,
    Email         NVARCHAR(255)     NOT NULL UNIQUE,
    DepartmentId  INT               NULL,
    IsActive      BIT               NOT NULL DEFAULT (1),
    CreatedAt     DATETIME2(0)      NOT NULL DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT FK_Users_Departments
        FOREIGN KEY (DepartmentId) REFERENCES dbo.Departments (DepartmentId)
);""",
        sqlite_ddl="""\
CREATE TABLE Users (
    UserId        INTEGER PRIMARY KEY AUTOINCREMENT,
    UserName      TEXT NOT NULL,
    Email         TEXT NOT NULL UNIQUE,
    DepartmentId  INTEGER NULL,
    IsActive      INTEGER NOT NULL DEFAULT 1,
    CreatedAt     TEXT NOT NULL,
    FOREIGN KEY (DepartmentId) REFERENCES Departments (DepartmentId)
);""",
    ),
    TableDef(
        name="dbo.LoginEvents",
        comment=(
            "One row per user login session. LogoutTimestamp is NULL when the "
            "session is still open or was never cleanly closed. Total logged-in "
            "time for a session is DATEDIFF(MINUTE, LoginTimestamp, "
            "LogoutTimestamp)."
        ),
        ddl="""\
CREATE TABLE dbo.LoginEvents (
    LoginEventId     BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    UserId           INT               NOT NULL,
    LoginTimestamp   DATETIME2(0)      NOT NULL,
    LogoutTimestamp  DATETIME2(0)      NULL,
    SourceIpAddress  VARCHAR(45)       NULL,
    CONSTRAINT FK_LoginEvents_Users
        FOREIGN KEY (UserId) REFERENCES dbo.Users (UserId)
);""",
        sqlite_ddl="""\
CREATE TABLE LoginEvents (
    LoginEventId     INTEGER PRIMARY KEY AUTOINCREMENT,
    UserId           INTEGER NOT NULL,
    LoginTimestamp   TEXT NOT NULL,
    LogoutTimestamp  TEXT NULL,
    SourceIpAddress  TEXT NULL,
    FOREIGN KEY (UserId) REFERENCES Users (UserId)
);""",
    ),
]

_DDL_BY_TABLE = {t.name: t for t in TABLES}
_SHORT_NAME_TO_FULL = {t.name.split(".")[-1].lower(): t.name for t in TABLES}


def _resolve_table_name(table_name: str) -> str | None:
    key = table_name.strip()
    if key in _DDL_BY_TABLE:
        return key
    return _SHORT_NAME_TO_FULL.get(key.lower())


def _seed(conn: sqlite3.Connection) -> None:
    cur = conn.cursor()
    for table in TABLES:
        cur.execute(table.sqlite_ddl)

    cur.executemany(
        "INSERT INTO Departments (DepartmentId, DepartmentName) VALUES (?, ?)",
        [(1, "Engineering"), (2, "Sales"), (3, "Support")],
    )

    cur.executemany(
        "INSERT INTO Users (UserId, UserName, Email, DepartmentId, IsActive, CreatedAt) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        [
            (1, "alice", "alice@example.com", 1, 1, "2025-01-10T09:00:00"),
            (2, "bob", "bob@example.com", 1, 1, "2025-02-14T09:00:00"),
            (3, "carla", "carla@example.com", 2, 1, "2025-03-01T09:00:00"),
            (4, "deepak", "deepak@example.com", 3, 1, "2025-03-20T09:00:00"),
            (5, "erin", "erin@example.com", 2, 0, "2025-04-05T09:00:00"),
        ],
    )

    # Login sessions spread across Q1-Q3 2026 so that "this quarter" and
    # "last quarter" resolve to genuinely different data. Durations (minutes)
    # are implied by (LoginTimestamp, LogoutTimestamp) deltas.
    sessions = [
        # Q1 2026 (Jan-Mar)
        (1, "2026-01-12T08:00:00", "2026-01-12T09:30:00", "10.0.0.11"),
        (2, "2026-02-03T08:00:00", "2026-02-03T08:45:00", "10.0.0.12"),
        (3, "2026-03-18T08:00:00", "2026-03-18T14:00:00", "10.0.0.13"),
        # Q2 2026 (Apr-Jun) == "last quarter" relative to 2026-09-16
        (1, "2026-04-02T08:00:00", "2026-04-02T12:00:00", "10.0.0.11"),
        (1, "2026-05-14T08:00:00", "2026-05-14T20:00:00", "10.0.0.11"),
        (2, "2026-04-20T08:00:00", "2026-04-20T09:00:00", "10.0.0.12"),
        (3, "2026-06-01T08:00:00", "2026-06-01T10:00:00", "10.0.0.13"),
        (4, "2026-06-10T08:00:00", "2026-06-10T18:30:00", "10.0.0.14"),
        # Q3 2026 (Jul-Sep) == current quarter
        (2, "2026-07-08T08:00:00", "2026-07-08T09:00:00", "10.0.0.12"),
        (4, "2026-08-22T08:00:00", "2026-08-22T09:15:00", "10.0.0.14"),
        (1, "2026-09-01T08:00:00", "2026-09-01T09:00:00", "10.0.0.11"),
    ]
    cur.executemany(
        "INSERT INTO LoginEvents (UserId, LoginTimestamp, LogoutTimestamp, SourceIpAddress) "
        "VALUES (?, ?, ?, ?)",
        sessions,
    )
    conn.commit()


class SchemaCatalog:
    """Holds the in-memory SQLite database used for schema + sample data."""

    def __init__(self) -> None:
        self._conn = sqlite3.connect(":memory:", check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        _seed(self._conn)

    def list_tables(self) -> list[str]:
        return [t.name for t in TABLES]

    def get_ddl(self, table_name: str | None = None) -> str:
        if not table_name or table_name.strip().upper() == "ALL":
            return "\n\n".join(
                f"-- {t.comment}\n{t.ddl}" for t in TABLES
            )
        full_name = _resolve_table_name(table_name)
        if full_name is None:
            known = ", ".join(self.list_tables())
            return f"ERROR: unknown table '{table_name}'. Known tables: {known}"
        table = _DDL_BY_TABLE[full_name]
        return f"-- {table.comment}\n{table.ddl}"

    def preview_rows(self, table_name: str, limit: int = 5) -> list[dict]:
        full_name = _resolve_table_name(table_name)
        if full_name is None:
            return []
        short_name = full_name.split(".")[-1]
        limit = max(1, min(int(limit), 20))
        cur = self._conn.execute(f"SELECT * FROM {short_name} LIMIT ?", (limit,))
        return [dict(row) for row in cur.fetchall()]


CATALOG = SchemaCatalog()


def today() -> datetime.date:
    return datetime.date.today()
