"""A Google ADK ``BaseLlm`` backed directly by the OpenAI Python client.

ADK ships a LiteLLM adapter for talking to non-Gemini models, but this
project is asked to use the OpenAI client explicitly. This module
implements the small translation layer ADK expects (``BaseLlm`` /
``LlmRequest`` / ``LlmResponse``) on top of ``openai.OpenAI().chat.completions``,
so the rest of the app (tools, agent loop, session state, CLI) is 100%
standard ADK.

An :class:`OfflineHeuristicLlm` fallback is also provided so the CLI keeps
working end-to-end when no ``OPENAI_API_KEY`` is configured (useful for
demos/tests without network access or credentials).
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from typing import Any, AsyncGenerator, Optional

from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.genai import types
from pydantic import PrivateAttr
from typing_extensions import override

from . import schema

logger = logging.getLogger("nl_sql_agent.llm")


# ---------------------------------------------------------------------------
# LlmRequest (google.genai types) <-> OpenAI chat.completions wire format
# ---------------------------------------------------------------------------


def _schema_to_json_schema(node: types.Schema) -> dict:
    """Recursively converts a google.genai types.Schema to plain JSON Schema."""
    dumped = node.model_dump(exclude_none=True)

    if "type" in dumped:
        t = dumped["type"]
        dumped["type"] = (t.value if isinstance(t, types.Type) else str(t)).lower()

    if "items" in dumped:
        items = node.items
        dumped["items"] = (
            _schema_to_json_schema(items)
            if isinstance(items, types.Schema)
            else _schema_to_json_schema(types.Schema.model_validate(dumped["items"]))
        )

    if "properties" in dumped and node.properties:
        dumped["properties"] = {
            key: _schema_to_json_schema(value) for key, value in node.properties.items()
        }

    return dumped


def _function_declaration_to_openai_tool(decl: types.FunctionDeclaration) -> dict:
    properties: dict[str, Any] = {}
    required: list[str] = []
    if decl.parameters and decl.parameters.properties:
        for key, value in decl.parameters.properties.items():
            properties[key] = _schema_to_json_schema(value)
        required = list(decl.parameters.required or [])

    return {
        "type": "function",
        "function": {
            "name": decl.name,
            "description": decl.description or "",
            "parameters": {
                "type": "object",
                "properties": properties,
                **({"required": required} if required else {}),
            },
        },
    }


def _content_to_messages(content: types.Content) -> list[dict]:
    """Converts one google.genai Content into 1+ OpenAI chat messages."""
    tool_messages = [
        {
            "role": "tool",
            "tool_call_id": part.function_response.id,
            "content": json.dumps(part.function_response.response or {}),
        }
        for part in content.parts
        if part.function_response
    ]
    if tool_messages:
        return tool_messages

    role = "assistant" if content.role in ("model", "assistant") else "user"
    text = "\n".join(part.text for part in content.parts if part.text)

    if role == "user":
        return [{"role": "user", "content": text}]

    tool_calls = [
        {
            "id": part.function_call.id,
            "type": "function",
            "function": {
                "name": part.function_call.name,
                "arguments": json.dumps(part.function_call.args or {}),
            },
        }
        for part in content.parts
        if part.function_call
    ]
    message: dict = {"role": "assistant", "content": text or None}
    if tool_calls:
        message["tool_calls"] = tool_calls
    return [message]


def _build_request(llm_request: LlmRequest) -> tuple[list[dict], Optional[list[dict]]]:
    messages: list[dict] = []
    if llm_request.config and llm_request.config.system_instruction:
        messages.append(
            {"role": "system", "content": llm_request.config.system_instruction}
        )
    for content in llm_request.contents or []:
        messages.extend(_content_to_messages(content))

    tools = None
    if (
        llm_request.config
        and llm_request.config.tools
        and llm_request.config.tools[0].function_declarations
    ):
        tools = [
            _function_declaration_to_openai_tool(decl)
            for decl in llm_request.config.tools[0].function_declarations
        ]
    return messages, tools


def _openai_response_to_llm_response(response: Any) -> LlmResponse:
    choice = response.choices[0]
    message = choice.message

    parts: list[types.Part] = []
    if message.content:
        parts.append(types.Part.from_text(text=message.content))
    for tool_call in message.tool_calls or []:
        args = json.loads(tool_call.function.arguments or "{}")
        part = types.Part.from_function_call(name=tool_call.function.name, args=args)
        part.function_call.id = tool_call.id
        parts.append(part)

    return LlmResponse(content=types.Content(role="model", parts=parts))


# ---------------------------------------------------------------------------
# The real model: OpenAI client
# ---------------------------------------------------------------------------


class OpenAIChatLlm(BaseLlm):
    """ADK model backend that calls the OpenAI Python client directly."""

    model: str = "gpt-4o-mini"
    temperature: float = 0.1

    _client: Any = PrivateAttr(default=None)

    @classmethod
    def supported_models(cls) -> list[str]:
        return [r"gpt-.*", r"o[0-9].*", r"chatgpt-.*"]

    def _client_instance(self):
        if self._client is None:
            import openai

            self._client = openai.OpenAI(
                api_key=os.environ.get("OPENAI_API_KEY"),
                base_url=os.environ.get("OPENAI_BASE_URL") or None,
            )
        return self._client

    @override
    async def generate_content_async(
        self, llm_request: LlmRequest, stream: bool = False
    ) -> AsyncGenerator[LlmResponse, None]:
        messages, tools = _build_request(llm_request)
        client = self._client_instance()

        kwargs: dict = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
        }
        if tools:
            kwargs["tools"] = tools

        response = await asyncio.to_thread(client.chat.completions.create, **kwargs)
        yield _openai_response_to_llm_response(response)


# ---------------------------------------------------------------------------
# Offline fallback: no network / no API key required
# ---------------------------------------------------------------------------


class OfflineHeuristicLlm(BaseLlm):
    """A tiny deterministic stand-in used when no OPENAI_API_KEY is set.

    It never calls any tool; it inspects the user's latest question with a
    couple of keyword heuristics and drafts T-SQL directly from the schema
    module, so the CLI remains runnable end-to-end without credentials.
    """

    model: str = "offline-heuristic"

    @classmethod
    def supported_models(cls) -> list[str]:
        return [r"offline-heuristic"]

    @override
    async def generate_content_async(
        self, llm_request: LlmRequest, stream: bool = False
    ) -> AsyncGenerator[LlmResponse, None]:
        question = ""
        for content in reversed(llm_request.contents or []):
            if content.role == "user":
                question = "\n".join(p.text for p in content.parts if p.text)
                break

        text = self._answer(question)
        yield LlmResponse(content=types.Content(role="model", parts=[types.Part.from_text(text=text)]))

    def _answer(self, question: str) -> str:
        q = question.lower()
        login_words = ("log in", "login", "logged in", "log-in", "session")
        time_words = ("quarter", "month", "week", "day", "year")

        if any(w in q for w in login_words) and any(w in q for w in time_words):
            return self._highest_logged_in_user_sql(q)

        tables = ", ".join(schema.CATALOG.list_tables())
        return (
            "[offline-heuristic mode: no OPENAI_API_KEY configured, so this is a "
            "template answer rather than a real LLM response]\n\n"
            "I can only demonstrate the canonical 'highest logged in user' query "
            "in offline mode. Set OPENAI_API_KEY and rerun to have the full ADK "
            f"agent reason about arbitrary questions over: {tables}."
        )

    def _highest_logged_in_user_sql(self, q: str) -> str:
        period = "QUARTER"
        offset = -1  # "last quarter"
        if "this month" in q:
            period, offset = "MONTH", 0
        elif "last month" in q:
            period, offset = "MONTH", -1
        elif "this quarter" in q:
            period, offset = "QUARTER", 0
        elif "last week" in q:
            period, offset = "WEEK", -1
        elif "this week" in q:
            period, offset = "WEEK", 0

        sql = f"""\
SELECT TOP (1)
    u.UserId,
    u.UserName,
    SUM(DATEDIFF(MINUTE, le.LoginTimestamp, le.LogoutTimestamp)) AS TotalMinutesLoggedIn
FROM dbo.LoginEvents AS le
INNER JOIN dbo.Users AS u
    ON u.UserId = le.UserId
WHERE le.LogoutTimestamp IS NOT NULL
    AND le.LoginTimestamp >= DATEADD({period}, DATEDIFF({period}, 0, GETDATE()) + ({offset}), 0)
    AND le.LoginTimestamp <  DATEADD({period}, DATEDIFF({period}, 0, GETDATE()) + ({offset} + 1), 0)
GROUP BY u.UserId, u.UserName
ORDER BY TotalMinutesLoggedIn DESC;
"""
        notes = (
            "Notes: 'highest logged in' is interpreted as the user with the "
            "greatest total logged-in minutes (SUM of session durations) in the "
            f"period. Date boundaries use the SQL Server idiom "
            f"DATEADD({period}, DATEDIFF({period}, 0, GETDATE()) + n, 0) to get "
            "the start of a calendar period without hardcoding today's date. "
            "Sessions with a NULL LogoutTimestamp (still open / not cleanly "
            "closed) are excluded."
        )
        return f"```sql\n{sql}```\n{notes}"
