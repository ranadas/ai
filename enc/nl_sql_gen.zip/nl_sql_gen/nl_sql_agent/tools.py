"""Tools the agent can call while composing SQL Server (T-SQL) queries.

These are plain, type-annotated Python functions. ADK inspects the
signature and docstring of each to build the function-calling schema it
hands to the LLM, so keep both accurate.
"""

from __future__ import annotations

from . import schema


def list_database_tables() -> list[str]:
    """Lists every table name available in the schema catalog.

    Call this first if you are not sure which tables exist.

    Returns:
        A list of fully qualified table names, e.g. ["dbo.Users", ...].
    """
    return schema.CATALOG.list_tables()


def get_table_ddl(table_name: str) -> str:
    """Returns the exact SQL Server CREATE TABLE DDL for one table.

    Always call this for every table you plan to reference before writing
    a query, so column names, data types, nullability and keys are exact.
    Never guess a column name.

    Args:
        table_name: A table name from list_database_tables (schema prefix
            optional, e.g. "Users" or "dbo.Users"). Pass "ALL" to fetch the
            DDL for every table in the schema at once.

    Returns:
        The CREATE TABLE statement text (with a leading comment describing
        the table), or an error message if the table is unknown.
    """
    return schema.CATALOG.get_ddl(table_name)


def preview_sample_rows(table_name: str, limit: int = 5) -> list[dict]:
    """Returns a few sample rows from a table for grounding purposes only.

    This is a convenience to help you understand the shape/values of the
    data (e.g. what a timestamp column looks like). The real query you
    produce will run against SQL Server, not against this sample data, so
    never rely on these exact values being present in production.

    Args:
        table_name: Table name, e.g. "LoginEvents" or "dbo.LoginEvents".
        limit: Maximum number of rows to return (1-20).

    Returns:
        A list of row dicts, or an empty list if the table is unknown.
    """
    return schema.CATALOG.preview_rows(table_name, limit)


def get_current_date() -> str:
    """Returns today's date as an ISO string (YYYY-MM-DD).

    Use this to resolve relative time phrases in the user's question
    ("last quarter", "this month", "last 7 days") into concrete date
    boundaries before writing SQL. Never assume today's date.

    Returns:
        Today's date, e.g. "2026-09-16".
    """
    return schema.today().isoformat()


ALL_TOOLS = [list_database_tables, get_table_ddl, preview_sample_rows, get_current_date]
