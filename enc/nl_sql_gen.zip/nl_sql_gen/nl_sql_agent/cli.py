"""Interactive REPL for the Natural Language -> SQL Server agent.

Run with ``python -m nl_sql_agent``. Type a question, get back a T-SQL
query you can run against SQL Server. The process keeps running until you
type `exit`/`quit` or press Ctrl-D.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
import warnings

# Quiet down third-party warnings (old google-auth/urllib3 combos on older
# Python) so they don't clutter an interactive session.
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", module="urllib3")
logging.getLogger("google_adk").setLevel(logging.ERROR)
logging.getLogger("google_genai").setLevel(logging.ERROR)

from google.adk.runners import InMemoryRunner  # noqa: E402
from google.genai import types  # noqa: E402

from . import schema  # noqa: E402
from .agent import build_agent  # noqa: E402

APP_NAME = "nl_sql_agent"
USER_ID = "cli-user"

HELP_TEXT = """\
Commands:
  <question>       Ask a natural-language analytics question.
  tables            List the tables the agent knows about.
  schema [table]    Print the T-SQL DDL for one table, or all tables.
  help              Show this message.
  exit | quit       Leave the program.

Example:
  what was our highest logged in user last quarter?
"""


def _banner(model_name: str) -> str:
    tables = ", ".join(schema.CATALOG.list_tables())
    return f"""\
Natural Language -> SQL Server (T-SQL) Agent
Model backend : {model_name}
Known tables  : {tables}

Ask a question in plain English; the agent will print a SQL Server query.
Type 'help' for commands, 'exit' to quit.
"""


def _print_tool_activity(event) -> None:
    for call in event.get_function_calls() or []:
        print(f"  → calling {call.name}({call.args})", file=sys.stderr)
    for resp in event.get_function_responses() or []:
        print(f"  ← {resp.name} returned", file=sys.stderr)


async def _ask(runner: InMemoryRunner, session_id: str, question: str) -> str:
    content = types.Content(role="user", parts=[types.Part(text=question)])
    final_text = ""
    async for event in runner.run_async(
        user_id=USER_ID, session_id=session_id, new_message=content
    ):
        _print_tool_activity(event)
        if event.is_final_response() and event.content and event.content.parts:
            final_text = "\n".join(p.text for p in event.content.parts if p.text)
    return final_text


async def main_async() -> None:
    agent = build_agent()
    runner = InMemoryRunner(agent=agent, app_name=APP_NAME)
    session = await runner.session_service.create_session(
        app_name=APP_NAME, user_id=USER_ID
    )

    print(_banner(agent.model.model))

    while True:
        try:
            question = input("nl-sql> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if not question:
            continue
        if question.lower() in ("exit", "quit"):
            break
        if question.lower() == "help":
            print(HELP_TEXT)
            continue
        if question.lower() == "tables":
            for name in schema.CATALOG.list_tables():
                print(f"  {name}")
            continue
        if question.lower().startswith("schema"):
            parts = question.split(maxsplit=1)
            table = parts[1] if len(parts) > 1 else None
            print(schema.CATALOG.get_ddl(table))
            continue

        try:
            answer = await _ask(runner, session.id, question)
        except Exception as exc:  # noqa: BLE001 - surface any backend error to the user
            print(f"[error] {exc}", file=sys.stderr)
            if not os.environ.get("OPENAI_API_KEY"):
                print(
                    "Hint: no OPENAI_API_KEY is set; the offline heuristic "
                    "backend is in use and only understands the sample "
                    "'highest logged in user' question.",
                    file=sys.stderr,
                )
            continue

        print()
        print(answer)
        print()


def main() -> None:
    asyncio.run(main_async())


if __name__ == "__main__":
    main()
