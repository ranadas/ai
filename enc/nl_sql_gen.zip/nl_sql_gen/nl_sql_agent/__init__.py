"""Natural Language -> SQL Server (T-SQL) agent, built on Google ADK."""
