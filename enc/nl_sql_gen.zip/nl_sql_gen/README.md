# Natural Language SQL Agent (SQL Server / T-SQL)

An agentic CLI that turns plain-English analytics questions into T-SQL
queries for Microsoft SQL Server. It never runs a query against a real
database -- it prints SQL text that a human then runs against SQL Server.

## How it's built

- **Google ADK** (`google-adk`) provides the agent runtime: the
  `Agent`/`LlmAgent`, the automatic tool-calling loop, and session state
  (`InMemoryRunner` + `InMemorySessionService`).
- **OpenAI client** (`openai` Python SDK) is called directly from a small
  custom ADK `BaseLlm` implementation (`nl_sql_agent/llm.py:OpenAIChatLlm`)
  instead of going through ADK's LiteLLM adapter. This satisfies "use the
  OpenAI client" while keeping everything else (tools, instructions,
  multi-turn loop) as standard ADK.
- **In-memory database**: `nl_sql_agent/schema.py` keeps an in-memory
  SQLite database that (a) stores the canonical SQL Server DDL text for
  every table, and (b) mirrors a handful of seed rows so the agent can
  optionally preview sample data. This stands in for a real connection to
  SQL Server's `INFORMATION_SCHEMA`.
- **Tools** (`nl_sql_agent/tools.py`): `list_database_tables`,
  `get_table_ddl`, `preview_sample_rows`, `get_current_date`. The agent is
  instructed to always fetch DDL before writing SQL and to resolve
  relative dates ("last quarter") using `get_current_date` plus T-SQL
  `DATEADD`/`DATEDIFF` idioms, rather than guessing.
- **CLI** (`nl_sql_agent/cli.py`): a REPL that keeps running until you type
  `exit`/`quit`, accepting a new question on every prompt.

If `OPENAI_API_KEY` is not set, the app falls back to a small deterministic
`OfflineHeuristicLlm` (also in `llm.py`) so the CLI still runs end-to-end
without credentials -- it can answer the canonical "highest logged in
user" question directly from the schema, but flags itself as offline mode
for anything else.

## Schema

```
dbo.Departments(DepartmentId PK, DepartmentName)
dbo.Users(UserId PK, UserName, Email, DepartmentId FK, IsActive, CreatedAt)
dbo.LoginEvents(LoginEventId PK, UserId FK, LoginTimestamp, LogoutTimestamp, SourceIpAddress)
```

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env   # then edit .env with your real key
export OPENAI_API_KEY=sk-...        # or `source .env` / use direnv
# optional: export OPENAI_MODEL=gpt-4o-mini
```

## Run

```bash
python -m nl_sql_agent
```

```
nl-sql> what was our highest logged in user last quarter?

  → calling get_current_date({})
  → calling get_table_ddl({'table_name': 'LoginEvents'})
  → calling get_table_ddl({'table_name': 'Users'})

```sql
SELECT TOP (1)
    u.UserId,
    u.UserName,
    SUM(DATEDIFF(MINUTE, le.LoginTimestamp, le.LogoutTimestamp)) AS TotalMinutesLoggedIn
FROM dbo.LoginEvents AS le
INNER JOIN dbo.Users AS u ON u.UserId = le.UserId
WHERE le.LogoutTimestamp IS NOT NULL
    AND le.LoginTimestamp >= DATEADD(QUARTER, DATEDIFF(QUARTER, 0, GETDATE()) - 1, 0)
    AND le.LoginTimestamp <  DATEADD(QUARTER, DATEDIFF(QUARTER, 0, GETDATE()), 0)
GROUP BY u.UserId, u.UserName
ORDER BY TotalMinutesLoggedIn DESC;
```
Notes: ...

nl-sql> tables
nl-sql> schema dbo.Users
nl-sql> exit
```

The tool-call trace lines (`→ calling ...`) print to stderr so stdout stays
clean SQL output if you redirect it.

## Tests

```bash
pip install -r requirements-dev.txt
python -m pytest tests/ -q
```

`tests/test_openai_backend.py` drives the real ADK `Agent` + tool-calling
loop end-to-end with the `OpenAI` client's `chat.completions.create`
replaced by a scripted stand-in (no network/API key needed), verifying the
`LlmRequest` <-> OpenAI wire-format translation in `nl_sql_agent/llm.py`.
