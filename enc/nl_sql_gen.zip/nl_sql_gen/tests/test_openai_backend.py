"""Exercises the full ADK agent loop against a mocked OpenAI client.

No network / API key is used: the OpenAI client's
``chat.completions.create`` is replaced with a scripted stand-in that
plays the part of the model across two turns (one turn requesting two
tool calls, one turn giving the final answer). This verifies the
LlmRequest<->OpenAI wire-format translation in ``nl_sql_agent.llm`` and
that ADK's automatic function-calling loop drives our tools correctly.
"""

import asyncio
import json
from types import SimpleNamespace

from google.adk.agents import Agent
from google.adk.runners import InMemoryRunner
from google.genai import types

from nl_sql_agent.agent import INSTRUCTION
from nl_sql_agent.llm import OpenAIChatLlm
from nl_sql_agent.tools import ALL_TOOLS


def _tool_call(call_id: str, name: str, arguments: dict) -> SimpleNamespace:
    return SimpleNamespace(
        id=call_id,
        type="function",
        function=SimpleNamespace(name=name, arguments=json.dumps(arguments)),
    )


def _response(*, content=None, tool_calls=None) -> SimpleNamespace:
    message = SimpleNamespace(content=content, tool_calls=tool_calls or [])
    choice = SimpleNamespace(message=message, finish_reason="stop")
    return SimpleNamespace(choices=[choice])


def test_agent_calls_tools_then_answers():
    turn_1 = _response(
        tool_calls=[
            _tool_call("call_1", "get_current_date", {}),
            _tool_call("call_2", "get_table_ddl", {"table_name": "LoginEvents"}),
        ]
    )
    turn_2 = _response(
        content=(
            "```sql\nSELECT TOP (1) UserId FROM dbo.LoginEvents;\n```\n"
            "Notes: mocked answer."
        )
    )

    calls = []

    def fake_create(**kwargs):
        calls.append(kwargs)
        return turn_1 if len(calls) == 1 else turn_2

    llm = OpenAIChatLlm(model="gpt-4o-mini")
    llm._client = SimpleNamespace(
        chat=SimpleNamespace(completions=SimpleNamespace(create=fake_create))
    )

    agent = Agent(
        name="test_agent",
        model=llm,
        instruction=INSTRUCTION,
        tools=ALL_TOOLS,
    )
    runner = InMemoryRunner(agent=agent, app_name="test_app")

    async def run():
        session = await runner.session_service.create_session(
            app_name="test_app", user_id="tester"
        )
        content = types.Content(
            role="user",
            parts=[types.Part(text="what was our highest logged in user last quarter?")],
        )
        final_text = ""
        async for event in runner.run_async(
            user_id="tester", session_id=session.id, new_message=content
        ):
            if event.is_final_response() and event.content and event.content.parts:
                final_text = "\n".join(p.text for p in event.content.parts if p.text)
        return final_text

    final_text = asyncio.run(run())

    assert len(calls) == 2, "expected two round-trips to the (mocked) OpenAI API"
    assert "```sql" in final_text
    assert "SELECT TOP (1)" in final_text

    # The first request must have advertised our tools to the model.
    first_tool_names = {t["function"]["name"] for t in calls[0]["tools"]}
    assert first_tool_names == {
        "list_database_tables",
        "get_table_ddl",
        "preview_sample_rows",
        "get_current_date",
    }

    # The second request must carry both tool results back to the model.
    second_messages = calls[1]["messages"]
    tool_messages = [m for m in second_messages if m["role"] == "tool"]
    assert {m["tool_call_id"] for m in tool_messages} == {"call_1", "call_2"}


if __name__ == "__main__":
    test_agent_calls_tools_then_answers()
    print("OK")
