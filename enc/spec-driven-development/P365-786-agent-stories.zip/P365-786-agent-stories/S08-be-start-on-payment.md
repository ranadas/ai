# S08 · [BE] Start-on-payment terms for lapses of 12 months or more

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365` / `equipe-service`, `plus365-db` |
| Depends on | S02 |
| Size | S |
| **Blocked by** | **Q3**: confirm "start = payment date" for lapses of 12 months or more. |

## User story

As the admin of an equipe that expired more than a year ago, I want my new year to start when my
payment arrives, so that I don't pay for a term that is already over.

## Context

S02 creates the pending term for `EXPIRED_LONG` with `start = today`. With bank transfers the
money can arrive days later, so the real start is only known when the webhook fires. The term is
flagged at creation and its dates are fixed on activation.

## Current code (read first)

- `equipe-service/src/main/java/com/arzamed/equipe/service/impl/RenewalEligibilityServiceImpl.java` (S02, `ensurePendingTerm`)
- `equipe-service/src/main/java/com/arzamed/equipe/service/impl/StripeWebhookServiceImpl.java` — `updateSubscription`, `updateSubscriptionForNoCostOrders`
- `equipe-service/src/main/java/com/arzamed/equipe/mapper/SubscriptionMapper.java` — `setSubscriptionAsActive`, `setSubscriptionDates`, `insertSubscriptionForEquipe`
- `plus365-db/src/main/resources/db/changelog/changelog-master.yaml` and an existing pair, e.g. `changelog-subscription-add-stripe-customer-root.yml` / `-v1.xml`

**Warning:** `setSubscriptionDates` writes `end_date = (#{endDate}::date + 1)`. Do not reuse it for
this story; add a dedicated update that writes the dates exactly.

## Tasks

1. Liquibase: `changelog-subscription-start-on-payment-root.yml` + `-v1.xml`, changeset id
   `SUB-START-ON-PAYMENT-01`, author from git config:
   `ALTER TABLE EQUIPE_SUBSCRIPTION ADD start_on_payment BOOLEAN NOT NULL DEFAULT FALSE`.
   Include the root file at the end of `changelog-master.yaml`. Update the H2 test schema.
2. Add `startOnPayment` to `EquipeSubscriptionDto` (in `arzamed-rest-client`), the result map and `insertSubscriptionForEquipe`.
3. `ensurePendingTerm`: for `EXPIRED_LONG`, set `startOnPayment = true` (provisional dates stay `today` / `today + 1 year`).
4. Webhook, in both activation paths, for a term with `startOnPayment = true`: in the same
   transaction as activation, set `start_date = today(clock)` and `end_date = start + 1 year`
   with the new mapper method, then clear the flag. Receipt email and cache eviction unchanged.
5. Include the final dates in the payment receipt request if the DTO supports them; otherwise leave it.

## Acceptance criteria

- Given an `EXPIRED_LONG` equipe, the pending term is created with `start_on_payment = true`.
- Given that term is paid 3 days after checkout, after the webhook `start_date` = payment day and `end_date` = payment day + 1 year, the flag is `false`, and `active_subscription = true`.
- Given an `EXPIRED_RECENT` or `EXPIRING` equipe, nothing changes: the flag is `false` and the dates are untouched by the webhook.
- Replaying the same webhook event does not move the dates again.
- The Liquibase changeset applies cleanly on PostgreSQL and H2.

## Tests

`StripeWebhookServiceImplTest` (fixed clock, both activation paths, replay), `SubscriptionMapperTest` for the new update, eligibility test for the flag.

## Guardrails

Conventions from `CLAUDE.md`; Liquibase in `plus365-db` only; MyBatis only.

## Out of scope

Anything for `EXPIRED_RECENT`. Changing `setSubscriptionDates` behaviour for existing callers.

## Definition of done

`mvn -B package -pl plus365-db,equipe-service -am` passes.
