# S11 · [FE] Renewal app scaffold, auth and local Keycloak client

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365-web` (new `projects/renewal`, `setenv.ts`, `projects/libs`), `plus365` (`keycloak-authorization-server` only) |
| Depends on | — |
| Size | M |

## User story

As a frontend developer, I want an empty but runnable renewal app with sign-in, token handling,
routing and guards in place, so that the screens (S12) can be built on a working base.

## Context

`plus365-web` is an Angular 18 monorepo with apps `client` (4200), `admin` (4300), `patient`
(4400) and the `libs` library. Environment values are generated into
`projects/libs/src/environments/environment.ts` by `setenv.ts` from `.env`, and read through
`AppConstants` in `projects/libs/src/lib/constants.ts`. The client app signs in with
`angular-oauth2-oidc` (code flow) against Cognito (UAT/PROD) or Keycloak (local).

## Current code (read first)

- `angular.json` (the `client` project block), `package.json` scripts, `setenv.ts`, `.env` keys (names only)
- `projects/libs/src/lib/constants.ts` (`CLIENT_APP_ID_PROVIDER_CLIENT_ID`, `CLIENT_APP_LOGOUT_URL`)
- `projects/client/src/main.ts`, `app.routes.ts`
- `projects/client/src/app/auth/auth-config.ts`, `auth/client-auth.service.ts` (`logout()` revokes the refresh token, then ends the IdP session)
- `projects/client/src/app/auth-interceptor.ts` (ID token by default, access token for `/user/mfa/`, refresh-on-401)
- `plus365/keycloak-authorization-server/Plus365-local-realm.json` (client `client-frontend`)

## Tasks

1. **Project**: add `renewal` to `angular.json` (copy the `client` block; output `dist/renewal`,
   dev-server port `4500`, no service worker, same styles pipeline, `it` locale).
   Scripts: `build:renewal` (`ng build renewal`) and `start:renewal` (`ng serve renewal`).
2. **Environment**: `setenv.ts` gains `RENEWAL_APP_ID_PROVIDER_CLIENT_ID` and
   `RENEWAL_APP_LOGOUT_URL` (same `''` → `undefined` handling as the other logout URLs);
   `AppConstants` gains matching constants. Document both in the README's environment section.
3. **Bootstrap** `projects/renewal/src/main.ts`: `provideRouter`, `provideHttpClient(withInterceptors([...]))`,
   `provideOAuthClient()`, `LOCALE_ID it-IT`, `GlobalErrorHandler` from libs. No NgRx.
4. **Auth** (`projects/renewal/src/app/auth/`):
   - `renewal-auth.config.ts`: like the client's, with the renewal client id, `redirectUri = origin + '/login'`,
     `postLogoutRedirectUri = origin + '/signed-out'`, `useSilentRefresh: false`.
   - `RenewalAuthService`: `init()` (load discovery document, try login), `login()`,
     `logout()` (revoke refresh token → clear storage → IdP logout, same order as `ClientAuthService.logout`),
     `claims()` signal.
   - Store tokens in `sessionStorage` (`provide: OAuthStorage, useFactory: () => sessionStorage`), so closing the tab ends the session.
5. **Interceptor** `renewal-auth.interceptor.ts`: same refresh-on-401 queueing as the client's
   interceptor. Send the **access** token to `/user/renewal/` and `/user/mfa/`, the **ID** token elsewhere
   (equipe-service reads the `email` claim, which only the ID token carries).
   On `403` with body `code = STEP_UP_REQUIRED`, navigate to `/verify`.
6. **Routes and guards** (`app.routes.ts`), with placeholder standalone components for S12:
   `/login`, `/verify`, `/equipes`, `/renew/:equipeId`, `/contact-admin/:equipeId`,
   `/payment-pending/:equipeId`, `/thanks`, `/signed-out`, `''` → `/equipes`, `**` → `/equipes`.
   Guards: `authGuard` (valid access token, else `login()`), `stepUpGuard` (calls
   `POST /user/renewal/session` once per app load and caches the result in a signal; redirects to `/verify` when `otpRequired`).
   `/login`, `/thanks`, `/signed-out` have no guard.
7. **Keycloak (local)**: in `Plus365-local-realm.json` add client `renewal-frontend` modelled on
   `client-frontend`: public client, standard flow, PKCE S256, redirect `http://localhost:4500/*`,
   web origin `http://localhost:4500`, post-logout redirect `http://localhost:4500/signed-out`.
8. **Shell**: minimal layout with ArzaMed logo, Italian copy, reusing libs styles. Title `ArzaMed - Rinnovo`.

## Acceptance criteria

- `npm run config && npm run build libs && npm run build:renewal` succeeds and produces `dist/renewal/index.html`.
- `ng serve renewal` on port 4500 redirects an anonymous user to the IdP and back to `/equipes` after sign-in (local Keycloak).
- Tokens are in `sessionStorage`, not `localStorage`.
- Requests to `/user/renewal/*` carry the access token; requests to equipe-service carry the ID token (unit test).
- A `403 STEP_UP_REQUIRED` response routes to `/verify` (unit test).
- `logout()` calls the revocation endpoint before redirecting to the IdP logout URL (unit test).
- The client, admin and patient apps still build.

## Tests

Specs for `RenewalAuthService`, the interceptor (token choice, refresh queueing, 403 handling) and both guards.

## Guardrails

- Angular 18 standalone APIs, signals; no NgRx in this app.
- Do not change the client app's auth code; copy and adapt instead of sharing mutable singletons.
- No secrets in the repo; `.env` values stay local.

## Out of scope

Screen content (S12). Cognito app client (S13). Pipelines (S14).

## Definition of done

Builds above pass; unit tests pass; README updated with how to run the renewal app locally.
