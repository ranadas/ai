# S13 · [INFRA] CDK stack and Cognito app client

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365-web` / new `infra/` |
| Depends on | — |
| Size | M |

## User story

As ArzaMed ops, we want the renewal app's hosting defined as code, so that UAT and PROD are
created the same way, reviewed in pull requests and reproducible.

## Decisions already made

- Domains: `renew.nextgen.arzamed.com` (PROD), `renew-test.nextgen.arzamed.com` (UAT).
- `arzamed.com` is a Route53 hosted zone; same AWS accounts and regions as the client app.
- Deployments use the existing stored AWS access keys (OIDC is separate, later work).
- Existing client/admin/patient hosting is **not** moved into CDK.

## Target layout

```
infra/
  package.json            # aws-cdk-lib v2, constructs, typescript, jest, ts-jest (pinned versions)
  cdk.json                # app: "npx ts-node --prefer-ts-exts bin/renewal.ts"
  tsconfig.json
  bin/renewal.ts          # instantiates stacks for uat and prod from config
  config/environments.ts  # typed config per environment (below)
  lib/renewal-cert-stack.ts   # us-east-1: ACM certificate
  lib/renewal-web-stack.ts    # home region: S3, CloudFront, Route53, Cognito client
  test/renewal-web-stack.test.ts
  README.md
```

```ts
export interface RenewalEnvConfig {
  envName: 'uat' | 'prod';
  account: string;            // from context/env, never hard-coded in the repo
  region: string;             // same as the client app
  hostedZoneName: string;     // 'arzamed.com'
  domainName: string;         // 'renew-test.nextgen.arzamed.com' | 'renew.nextgen.arzamed.com'
  userPoolId: string;         // existing Cognito pool (context)
  apiOrigins: string[];       // for CSP connect-src, e.g. the service URLs used by the web apps
  cognitoDomain: string;      // Hosted UI domain, for CSP connect-src and form-action
}
```

Values for `account`, `userPoolId`, `apiOrigins`, `cognitoDomain` come from CDK context
(`-c env=uat` plus `cdk.context.json` kept out of git) or environment variables; the README lists them.

## Resources

1. **Certificate stack** (`us-east-1`, `crossRegionReferences: true`): ACM certificate for
   `domainName`, DNS-validated in the imported hosted zone.
2. **Web stack** (home region):
   - **S3 bucket**: block all public access, `BucketEncryption.S3_MANAGED`, `enforceSSL`,
     versioned, lifecycle rule expiring non-current versions after 30 days,
     `RemovalPolicy.RETAIN`, `autoDeleteObjects: false`.
   - **CloudFront distribution**: `S3BucketOrigin.withOriginAccessControl`, default root
     object `index.html`, error responses 403 and 404 → `/index.html` with 200, HTTP/2 and 3,
     compression, `PriceClass_100`, TLS 1.2_2021, the certificate, alias `domainName`.
     Cache policy: default `CACHING_OPTIMIZED`; the deploy pipeline sets `Cache-Control` per object (S14).
   - **Response headers policy**: HSTS (2 years, includeSubDomains, preload), `X-Content-Type-Options`,
     `Referrer-Policy: strict-origin-when-cross-origin`, `X-Frame-Options: DENY`, and a CSP:
     `default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self' <apiOrigins> <cognitoDomain>; frame-ancestors 'none'; form-action 'self' <cognitoDomain>; base-uri 'self'`.
     Check the built app for any other origin it calls and add it to config, not inline.
   - **Route53**: `ARecord` and `AaaaRecord` alias records for `domainName` → distribution.
   - **Cognito app client** on the imported pool (`UserPool.fromUserPoolId`): no secret,
     `authFlows` none, OAuth code grant only, scopes `openid email profile`,
     callback `https://<domainName>/login`, logout `https://<domainName>/signed-out`,
     `preventUserExistenceErrors: true`, access/ID token validity same as the client app's client
     (read from the existing client and set explicitly), supported IdP `COGNITO`.
   - **Outputs**: `BucketName`, `DistributionId`, `DistributionDomainName`, `UserPoolClientId`.
3. Tags on everything: `project=plus365`, `component=renewal-web`, `env=<envName>`.

## Acceptance criteria (jest, `aws-cdk-lib/assertions`)

- The bucket has public access fully blocked, encryption, versioning and `DeletionPolicy: Retain`.
- The distribution uses origin access control (no OAI, no public bucket policy) and has both SPA error responses.
- The CSP header contains every `apiOrigins` entry and `frame-ancestors 'none'`.
- The Cognito client allows only the code grant, has no secret, and its callback and logout URLs use `domainName`.
- Two alias records exist for `domainName`.
- The certificate stack is in `us-east-1`; the web stack consumes it through a cross-region reference.
- `npx cdk synth -c env=uat` and `-c env=prod` succeed with example context.

## Guardrails

- No account ids, pool ids or secrets committed. Example values in `README.md` only.
- Do not import or modify existing buckets, distributions or Cognito clients other than adding the new client to the existing pool.
- Pin CDK and construct versions.

## Out of scope

GitHub OIDC roles. Pipelines (S14). Moving other apps into CDK.

## Definition of done

`npm ci && npm test && npx cdk synth -c env=uat` pass in `infra/`; README explains bootstrap
(`cdk bootstrap` in the home region **and** `us-east-1` for both accounts) and first deploy.
