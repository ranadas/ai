# S05 · [BE] user-service: expired equipes and equipe admins endpoints

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365` / `user-service` |
| Depends on | — |
| Size | M |
| **Blocked by** | **Q4**: definition of "admin". Working assumption below; edit this story if the answer differs. |

## User story

As a user of an expired equipe, I want to see which of my expired equipes I can renew, and for
the others, who my equipe admins are, so that I either renew or know whom to contact.

## Working assumption (Q4)

- "Can renew" = the user holds permission `ALL_MODIFY` on service `EQUIPE` in that equipe
  (the same permission the renewal payment already requires). It is **not** based on the
  `EQUIPE_ADMIN` user type.
- The admin list shows first and last names only, and only to active members of that equipe.

## Context

`UserMapper.findEquipeForUser` already returns each of a user's equipes with an `equipeExpired`
flag (no active subscription covers today). `userinfo-service` uses it to hide expired equipes.
Permission checks live in `PermissionMapper.isPermissionGrantedToUserInEquipe` and do not look at
subscription status, so they work for expired equipes.

## Current code (read first)

- `user-service/src/main/java/com/arzamed/user/mapper/UserMapper.java` — `findEquipeForUser`
- `user-service/src/main/java/com/arzamed/user/mapper/PermissionMapper.java` — `isPermissionGrantedToUserInEquipe`
- `user-service/src/main/java/com/arzamed/user/service/impl/UserServiceImpl.java` — `hasPermission`, `getUser`
- `user-service/src/main/resources/user-service.yaml`
- `user-service/src/main/java/com/arzamed/user/config/SecurityConfiguration.java`
- `user-service/src/test/java/com/arzamed/user/resource/impl/MfaControllerTest.java` (controller test style)

## Tasks

1. OpenAPI (`user-service.yaml`), tag `renewal`:
   ```yaml
   /user/renewal/equipes:
     get:
       operationId: listRenewalEquipes
       responses:
         '200': { content: { application/json: { schema: { type: array, items: { $ref: '#/components/schemas/RenewalEquipeDto' } } } } }
   /user/renewal/equipes/{equipeId}/admins:
     get:
       operationId: listRenewalEquipeAdmins
       parameters: [ { in: path, name: equipeId, required: true, schema: { type: string, format: uuid } } ]
       responses:
         '200': { content: { application/json: { schema: { type: array, items: { $ref: '#/components/schemas/EquipeAdminNameDto' } } } } }
         '403': { description: Caller is not an active member of the equipe }
   components:
     schemas:
       RenewalEquipeDto:
         type: object
         required: [equipeId, name, canRenew]
         properties:
           equipeId: { type: string, format: uuid }
           name: { type: string }
           displayName: { type: string, nullable: true }
           canRenew: { type: boolean }
       EquipeAdminNameDto:
         type: object
         required: [firstName, lastName]
         properties:
           firstName: { type: string }
           lastName: { type: string }
   ```
2. `RenewalEquipeService` (+ impl) in `service/`:
   - `listRenewalEquipes(email)`: user must exist and be enabled. Return the user's equipes where
     the association is active and `equipeExpired = true`, each with `canRenew` from the
     permission check. Sort by display name, then name.
   - `listEquipeAdmins(email, equipeId)`: caller must have an active association with the equipe
     (else `403`). Return active, enabled users of that equipe who hold `EQUIPE`/`ALL_MODIFY`,
     names only, sorted by last name. Add one mapper query for this; do not call the permission
     check once per user.
3. Controller reads the email from the JWT `email` claim, like `MfaController` reads the principal.
4. Both endpoints use the default authenticated filter chain (not `permitAll`).

## Acceptance criteria

- Given a user with one active and one expired equipe, `listRenewalEquipes` returns only the expired one.
- Given the user holds `EQUIPE`/`ALL_MODIFY` in the expired equipe, `canRenew = true`; otherwise `false`.
- Given an inactive association (`USER_EQUIPE.active = false`) to an expired equipe, it is not returned.
- Given a caller who is not an active member, `/admins` returns `403`.
- The `/admins` response contains only `firstName` and `lastName`; no email, phone or id appears in the JSON.
- Disabled users are never listed as admins.

## Tests

- `UserMapperTest` (H2) for the new admin query.
- `RenewalEquipeServiceImplTest` for filtering and `canRenew`.
- `RenewalEquipeControllerTest` (`@WithMockOAuth2User`) for 200/403 and the JSON shape (assert absent fields).

## Guardrails

- Personal data: return names only, and only to members of the same equipe.
- OpenAPI first, then regenerate. MyBatis only. Conventions from `CLAUDE.md`.

## Out of scope

Step-up/OTP (S06). Frontend. Any change to `userinfo-service`.

## Definition of done

`mvn -B package -pl user-service -am` passes.
