# S07 · [BE] Enforce step-up on renewal endpoints (equipe-service)

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365` / `equipe-service` |
| Depends on | S02, S06 |
| Size | S |
| **Blocked by** | **Q2** (same assumption as S06) |

## User story

As ArzaMed, we want renewal actions on an expired equipe to require a verified second factor on
the server, so that the OTP cannot be bypassed by calling the API directly with a stolen password.

## Rule

For renewal endpoints, when the equipe's eligibility is `EXPIRED_RECENT` or `EXPIRED_LONG`, the
caller's session (`sub` + `auth_time` from the JWT) must be verified by user-service's internal
`checkRenewalStepUp` (S06). Otherwise respond `403` with `code: STEP_UP_REQUIRED`.
Equipes in `ACTIVE` or `EXPIRING` are **not** affected, so the client app is unchanged (the
client app can never open an expired equipe).

## Current code (read first)

- `equipe-service/src/main/java/com/arzamed/equipe/resource/impl/SubscriptionController.java`
- `equipe-service/src/main/java/com/arzamed/equipe/service/impl/SubscriptionServiceImpl.java`
- `RenewalEligibilityService` (S02); `/equipe/subscription/renewal-status` (S04)
- `equipe-service/src/main/java/com/arzamed/equipe/config/RestClientConfiguration.java` and the user client in `arzamed-rest-client` (method added in S06)

## Tasks

1. `StepUpVerifier` interface + impl in `service/`: `void requireVerified(Jwt jwt)`; reads `sub`
   and `auth_time` (Cognito sends `auth_time` as epoch seconds), calls the internal endpoint,
   throws `StepUpRequiredException` when not verified or when user-service cannot be reached
   (fail closed).
2. Cache positive results in memory for 60 seconds per `sub:auth_time`
   (Caffeine if already a dependency, otherwise a small `ConcurrentHashMap` with expiry);
   never cache negatives.
3. Apply the rule to: `GET /equipe/subscription/next`, `POST /equipe/subscription/renew`,
   `POST /equipe/subscription/renew/change-edition`, `GET /equipe/subscription/renewal-quote`,
   `GET /equipe/subscription/renewal-status`, `GET /equipe/subscription/edition/list`.
   Pass the `Jwt` (or a small `CallerContext` record with `email`, `sub`, `authTime`) from the
   controller into the service, so the check runs after eligibility is known.
4. Map `StepUpRequiredException` to `403` with body `{ "code": "STEP_UP_REQUIRED" }` and add the
   response to the OpenAPI spec for those paths.

## Acceptance criteria

- Given an `EXPIRED_RECENT` equipe and an unverified session, every listed endpoint returns `403 STEP_UP_REQUIRED`.
- Given the same equipe and a verified session, the endpoints behave as in S02–S04.
- Given an `EXPIRING` equipe, no call to user-service is made (verify with the mock).
- Given user-service is down, expired-equipe requests fail with `403`, and expiring-equipe requests still work.
- A positive result is reused within 60 s (one internal call for two requests).

## Tests

`StepUpVerifierImplTest` (claims parsing, cache, fail-closed) and `SubscriptionControllerTest`
cases with `@WithMockOAuth2User` including `sub` and `auth_time` claims (extend the annotation
factory if it cannot set them).

## Guardrails

Do not add the check to webhook or internal endpoints. OpenAPI first, then regenerate.
Conventions from `CLAUDE.md`.

## Out of scope

apikey-service (S09).

## Definition of done

`mvn -B package -pl equipe-service -am` passes.
