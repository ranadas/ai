# S02 · [BE] RenewalEligibilityService and renewal endpoint refactor

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365` / `equipe-service` |
| Depends on | S01 |
| Size | L |

## User story

As the admin of an equipe whose subscription has expired, I want the renewal endpoints to accept
my equipe, so that I can pay for a new term instead of being told my subscription "is not yet expired".

## Context

Every renewal path decides eligibility on its own, using `isEquipeCloseToExpiration()`, which
requires an active term covering today. After expiry it returns `false`, and the endpoints throw
`SubscriptionException("current subscription is not yet expired")`. This story introduces a single
source of truth for eligibility and switches all renewal paths to it.

## Eligibility states (implement exactly)

Computed from S01's `findLastTermInForce` (`last`) and `findPendingTerm` (`pending`), with
`today = LocalDate.now(clock)`:

| State | Rule |
|---|---|
| `ACTIVE` | `last` covers today and `last.endDate - today > expiryDays` |
| `EXPIRING` | `last` covers today and `0 <= last.endDate - today <= expiryDays` |
| `EXPIRED_RECENT` | `last.endDate < today` and `today < last.endDate + lapseMonths` |
| `EXPIRED_LONG` | `last.endDate < today` and `today >= last.endDate + lapseMonths` |
| `NO_TERM` | no term in force at all |

- `expiryDays` = existing property `equipe.subscription.expiry` (15).
- `lapseMonths` = new property `equipe.subscription.renewal.long-lapse-months`, default `12`.
- `PAYMENT_PENDING` is **not** computed here; S04 adds it from Stripe.
- A `java.time.Clock` bean is added to equipe-service config (`Clock.systemDefaultZone()`), so
  tests can inject a fixed clock.

## Current code (read first)

- `equipe-service/src/main/java/com/arzamed/equipe/service/impl/SubscriptionServiceImpl.java`
  — `getNextSubscription`, `generateNextSubscriptionPaymentLink`,
  `changeEditionAtSubscriptionRenewal`, `createNextSubscriptionForExpiringEquipes`,
  `createCheckoutSessionForSubscription`
- `equipe-service/src/main/java/com/arzamed/equipe/mapper/SubscriptionMapper.java` (S01 queries)
- `equipe-service/src/main/java/com/arzamed/equipe/service/impl/StripeWebhookServiceImpl.java`
  (read only: understand how `isCreatedBySystem` terms are activated)
- `equipe-service/src/main/resources/application.yaml` (`equipe.subscription.expiry`)
- `equipe-service/src/test/java/com/arzamed/equipe/service/impl/SubscriptionServiceImplTest.java`

## Tasks

1. Create in `service/`:
   ```java
   public enum RenewalEligibility { ACTIVE, EXPIRING, EXPIRED_RECENT, EXPIRED_LONG, NO_TERM;
       public boolean canRenew() { return this == EXPIRING || isExpired(); }
       public boolean isExpired() { return this == EXPIRED_RECENT || this == EXPIRED_LONG; } }

   public record RenewalContext(RenewalEligibility eligibility,
                                Optional<EquipeSubscriptionDto> lastTerm,
                                Optional<EquipeSubscriptionDto> pendingTerm) {}

   public interface RenewalEligibilityService {
       RenewalContext evaluate(String equipeId);
       /** Returns the pending term, creating it if missing. Throws if !canRenew(). */
       EquipeSubscriptionDto ensurePendingTerm(String equipeId, String editionId);
   }
   ```
2. Implement `RenewalEligibilityServiceImpl` in `service/impl/` (pure date logic + mapper calls).
3. `ensurePendingTerm` is `@Transactional`:
   - calls `subscriptionMapper.lockEquipe(equipeId)` first (row lock, serialises concurrent calls);
   - re-reads the pending term after the lock and returns it if it exists and has the requested edition;
   - otherwise creates it. Dates: `start = last.endDate`, `end = start.plusYears(1)`
     for `EXPIRING` and `EXPIRED_RECENT`. For `EXPIRED_LONG` use `start = today`,
     `end = today.plusYears(1)` (S08 later makes this "start on payment").
   - Amount, discount and VAT: extract the calculation now duplicated in
     `createNextSubscriptionForExpiringEquipes`, `generateNextSubscriptionPaymentLink` and
     `changeEditionAtSubscriptionRenewal` into one package-private helper
     (`SubscriptionPricing.annualAmount(edition, equipe)`), and use it everywhere.
4. Refactor the three renewal paths in `SubscriptionServiceImpl`:
   - Replace `isEquipeCloseToExpiration(...)` guards with `evaluate(equipeId).eligibility().canRenew()`.
     Error message when not allowed: `"subscription is not eligible for renewal (state: X)"`.
   - `getNextSubscription` returns `pendingTerm` (creating it via `ensurePendingTerm` with the
     current edition if missing).
   - `generateNextSubscriptionPaymentLink` uses `ensurePendingTerm(equipeId, currentEditionId)`.
   - `changeEditionAtSubscriptionRenewal` no longer calls `findCurrentSubscription()` or
     `findNextSubscription()`. It replaces the pending term with one for the requested edition,
     inside the same transaction and lock. Keep the existing max-users check.
   - `createNextSubscriptionForExpiringEquipes` (scheduler) uses `SubscriptionPricing` but keeps its behaviour.
5. Leave `isEquipeCloseToExpiration` in the mapper if other callers still use it; otherwise delete it.

## Acceptance criteria

- Given a term ending in 20 days, `evaluate` returns `ACTIVE`; 15 days → `EXPIRING`; ending today → `EXPIRING`.
- Given a term that ended yesterday, → `EXPIRED_RECENT`; ended 365 days ago with `lapseMonths = 12`
  (end date + 12 months ≤ today) → `EXPIRED_LONG`; ended 364 days ago → `EXPIRED_RECENT`.
- Given an `EXPIRED_RECENT` equipe with no pending term, when `generateNextSubscriptionPaymentLink`
  is called by a user with `EQUIPE`/`ALL_MODIFY`, then a pending term is created with
  `start = last.endDate`, `end = start + 1 year`, and a Stripe checkout URL is returned.
- Given two concurrent `ensurePendingTerm` calls for the same equipe, then exactly one pending term exists afterwards.
- Given an `ACTIVE` equipe, renewal endpoints still refuse (unchanged behaviour for the client app).
- Given an `EXPIRING` equipe, the client-app renewal behaves exactly as before
  (existing `SubscriptionServiceImplTest` and `SubscriptionControllerTest` pass unchanged, except
  for the error message text).
- `changeEditionAtSubscriptionRenewal` for an `EXPIRED_RECENT` equipe creates the pending term
  for the new edition with dates from the last term in force.

## Tests

- `RenewalEligibilityServiceImplTest`: parameterised test over the state table with a fixed
  `Clock`, including all boundaries above.
- `SubscriptionServiceImplTest`: expired-equipe cases for the three renewal paths
  (`@MockitoBean StripeService`).
- `SubscriptionMapperTest` or a service-level H2 test for the concurrency case (two threads,
  `CountDownLatch`).

## Guardrails

- Do not change public API contracts (OpenAPI) in this story.
- Do not change the webhook (`StripeWebhookServiceImpl`) in this story.
- Money is `BigDecimal` with the existing rounding (`RoundingMode.HALF_UP`, scale 10 for
  percentages, scale 2 for prices); keep results identical to today for existing cases.
- MyBatis only; `@MockitoBean` not `@MockBean`; `@ActiveProfiles({"test", "dev-local"})`.

## Out of scope

Stripe URL changes (S04), step-up checks (S07), start-on-payment (S08), API plans (S09).

## Definition of done

- `mvn -B package -pl equipe-service -am` passes, including checkstyle and licence checks.
- No remaining call to `isEquipeCloseToExpiration` in the three renewal paths.
