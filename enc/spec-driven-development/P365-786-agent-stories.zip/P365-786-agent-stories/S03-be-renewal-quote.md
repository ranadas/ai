# S03 · [BE] renewal-quote authorisation and term dates

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365` / `equipe-service`, `arzamed-rest-client` (if the DTO lives there) |
| Depends on | S02 |
| Size | S |

## User story

As the admin of an expired equipe, I want the renewal quote to show the exact period I am paying
for, and only people from my equipe may see my prices.

## Context

`GET /equipe/subscription/renewal-quote` (`SubscriptionServiceImpl.getRenewalQuote`) has **no
caller check**: any authenticated user can pass any `X-Equipe-Id` and read that equipe's
discount and prices. It also does not say which dates the new term will cover, which matters
now that an expired equipe may pay for a term that started in the past.

## Current code (read first)

- `equipe-service/src/main/resources/equipe-service.yaml` — path `/equipe/subscription/renewal-quote`, schema `RenewalQuoteDto`
- `equipe-service/src/main/java/com/arzamed/equipe/resource/impl/SubscriptionController.java` — `getRenewalQuote`
- `equipe-service/src/main/java/com/arzamed/equipe/service/impl/SubscriptionServiceImpl.java` — `getRenewalQuote`, `validateUserAndEquipeData`
- `RenewalEligibilityService` from S02

## Tasks

1. Controller: read the caller's email from the JWT (`jwt.getClaimAsString("email")`), as the
   other methods in `SubscriptionController` do, and pass it to the service.
2. Service: `getRenewalQuote(String userEmail, String equipeId, String editionId)`:
   - `validateUserAndEquipeData(userEmail, equipeId)` then require `EQUIPE` / `ALL_VIEW`.
   - Evaluate eligibility (S02). If `!canRenew()`, return the quote without dates
     (the client app also uses this endpoint for display).
   - If `canRenew()`, add the dates of the term that the payment would create, using the same
     date rules as `ensurePendingTerm` (**read only; do not create rows here**).
3. OpenAPI: extend `RenewalQuoteDto` with
   ```yaml
   eligibility: { type: string, enum: [ACTIVE, EXPIRING, EXPIRED_RECENT, EXPIRED_LONG, NO_TERM] }
   termStart:   { type: string, format: date, nullable: true }
   termEnd:     { type: string, format: date, nullable: true }
   ```
   Add `403` to the path's responses. Regenerate the API interfaces; do not hand-edit them.
4. Map `SubscriptionException` for permission failures to `403`, not `404`/`400`.
5. Frontend clients are regenerated in S10 and S12; this story only changes the backend.

## Acceptance criteria

- Given a user who is not a member of the equipe, the endpoint returns `403`.
- Given a member without `EQUIPE`/`ALL_VIEW`, it returns `403`.
- Given an `EXPIRED_RECENT` equipe whose last term ended on 2026-08-31, the response has
  `eligibility = EXPIRED_RECENT`, `termStart = 2026-08-31`, `termEnd = 2027-08-31`.
- Given an `ACTIVE` equipe, `termStart` and `termEnd` are `null`, and amounts are unchanged from today.
- Calling the endpoint never inserts or updates a subscription row.

## Tests

- `SubscriptionControllerTest`: 403 cases and a 200 case (`@WithMockOAuth2User`).
- `SubscriptionServiceImplTest`: dates for `EXPIRING`, `EXPIRED_RECENT`, `EXPIRED_LONG`; no mapper writes (`verify(..., never())`).

## Guardrails

- OpenAPI first, then regenerate (`openapi-generator-maven-plugin`, sources copied into `src/main/java`).
- Keep the response backward compatible: only add fields.
- Conventions from `CLAUDE.md` (checkstyle, licence header, Jackson 3).

## Out of scope

Any change to how amounts are calculated. Frontend changes.

## Definition of done

`mvn -B package -pl equipe-service -am` passes; the regenerated interface and YAML are in the same commit.
