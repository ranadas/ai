# S04 · [BE] Stripe return target, cancel URL, superseded sessions, renewal status

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365` / `equipe-service`, `uat-k8s`, `prod-k8s`, `local-k8s` |
| Depends on | S02 |
| Size | M |

## User story

As an admin paying from the renewal app, I want Stripe to bring me back to the renewal app,
never charge me for a checkout that was replaced, and tell me when a bank transfer is still on its way.

## Context

- `StripeServiceImpl.createCheckoutSession` hardcodes `success_url = ${FRONTEND_URI}/payment-done/c`
  (the client app) and sets no `cancel_url`.
- **Lost-payment bug:** a user opens checkout A, then changes edition (the pending term is
  deleted and recreated with checkout B), then pays A. The webhook finds no subscription for
  session A and ignores the payment. The session id is already stored on the subscription row
  by `setPaymentLinkForSubscription`, so it can be expired before the row is replaced.
- Checkout allows `CARD` and `CUSTOMER_BALANCE` (EU bank transfer). With a bank transfer the
  session completes before the money arrives, so the renewal app needs a way to show
  "payment in progress" and must not offer a second checkout.

## Current code (read first)

- `equipe-service/src/main/java/com/arzamed/equipe/service/impl/StripeServiceImpl.java` — `createCheckoutSession`
- `equipe-service/src/main/java/com/arzamed/equipe/service/StripeService.java`
- `equipe-service/src/main/java/com/arzamed/equipe/service/impl/SubscriptionServiceImpl.java` — `createCheckoutSessionForSubscription`, the renewal paths refactored in S02
- `equipe-service/src/main/java/com/arzamed/equipe/mapper/SubscriptionMapper.java` — `setPaymentLinkForSubscription`, `deleteNextSubscriptionOnRenewal`, `findSubscriptionByCheckoutSessionId`
- `equipe-service/src/main/resources/equipe-service.yaml` — `/equipe/subscription/renew`, `/equipe/subscription/renew/change-edition`
- `equipe-service/src/main/resources/application.yaml` and `*-k8s/equipe-microservice.yml`, `*-k8s/config-map.yml` (`FRONTEND_URI` ← `frontend.uri`)

## Tasks

1. **Return target**
   - OpenAPI: add optional query parameter `returnTarget` (`enum: [CLIENT, RENEWAL]`, default
     `CLIENT`) to `POST /equipe/subscription/renew` and `POST /equipe/subscription/renew/change-edition` (both already take header `X-Equipe-Id`).
   - New property `RENEWAL_FRONTEND_URI` → config-map key `renewal_frontend.uri`
     (UAT `https://renew-test.nextgen.arzamed.com`, PROD `https://renew.nextgen.arzamed.com`,
     local `http://localhost:4500`). Add it to the three config maps and the equipe-service deployments.
   - `StripeService.createCheckoutSession(amount, productName, customer, CheckoutReturn ret)`
     where `CheckoutReturn` is a record `(String successUrl, String cancelUrl)` built by a small
     `CheckoutReturnFactory`:
     - `CLIENT`: success `${FRONTEND_URI}/payment-done/c` (unchanged), cancel `${FRONTEND_URI}/equipe`.
     - `RENEWAL`: success `${RENEWAL_FRONTEND_URI}/thanks?session_id={CHECKOUT_SESSION_ID}`,
       cancel `${RENEWAL_FRONTEND_URI}/renew/{equipeId}?cancelled=1`.
2. **Expire superseded sessions**
   - Before a pending term is deleted or replaced (change edition) and before a new checkout is
     created for a pending term that already has a session id, retrieve that session:
     - `status = open` → call `expire()`, then continue;
     - `status = complete` and `payment_status = unpaid` → **refuse** with a new
       `PaymentPendingException` mapped to HTTP `409` (`code: PAYMENT_PENDING`);
     - `status = complete` and `payment_status = paid` → refuse with `409` (`code: ALREADY_PAID`);
     - `status = expired` → continue.
   - If Stripe cannot be reached, fail the request (do not create a second session).
3. **Renewal status endpoint**
   - `GET /equipe/subscription/renewal-status` with header `X-Equipe-Id`, caller needs
     `EQUIPE`/`ALL_VIEW`. Response `RenewalStatusDto { status: NONE | PAYMENT_PENDING | PAID }`
     from the pending term's session, using the same rules as above
     (`PAID` = session paid but webhook not yet processed).
4. Keep the webhook unchanged: it already activates by checkout session id.

## Acceptance criteria

- Given `returnTarget` is omitted, the created session has the same success URL as today and a cancel URL to `/equipe`.
- Given `returnTarget=RENEWAL`, the session's success and cancel URLs point to the renewal app, with `{CHECKOUT_SESSION_ID}` left for Stripe to fill in.
- Given a pending term with an open session A, when the user changes edition, then A is expired and a new session B is stored on the new pending term.
- Given a pending term whose session is complete and unpaid (bank transfer), when the user tries to pay or change edition, then the API returns `409 PAYMENT_PENDING` and no session is created.
- `renewal-status` returns `PAYMENT_PENDING` for that equipe, `NONE` when there is no session or it is expired.
- A user without `EQUIPE`/`ALL_VIEW` gets `403` from `renewal-status`.

## Tests

- `StripeServiceImplTest` (new): URL building for both targets.
- `SubscriptionServiceImplTest`: expire-then-replace, 409 cases, Stripe failure (mock `StripeService`; wrap Stripe static calls such as `Session.retrieve` behind `StripeService` methods so they can be mocked).
- `SubscriptionControllerTest`: `returnTarget` binding, `renewal-status` 200/403/409 mapping.

## Guardrails

- All Stripe SDK calls stay inside `StripeServiceImpl`; the subscription service only talks to the `StripeService` interface.
- Stripe keys and webhook secrets stay in Kubernetes secrets; never log them or session URLs with tokens.
- OpenAPI first, then regenerate. Conventions from `CLAUDE.md`.

## Out of scope

Webhook changes (S08), step-up checks (S07), frontend.

## Definition of done

- `mvn -B package -pl equipe-service -am` passes.
- Config-map and deployment changes present for local, UAT and PROD.
- Manual check in Stripe test mode (developer): open checkout, change edition, confirm the first session shows as expired in the Stripe dashboard.
