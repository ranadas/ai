# S14 · [INFRA] UAT and PROD pipelines for the renewal app

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365-web` / `.github/workflows` |
| Depends on | S11 (app builds), S13 (stack outputs) |
| Size | S |

## User story

As a developer, I want manual pipelines that deploy the renewal app's infrastructure and code to
UAT and PROD, in the same style as the existing web pipelines, so that releases are repeatable.

## Context

Existing web pipelines (`.github/workflows/uat-build-client.yml`, `prod-build-client.yml`, …)
run on `workflow_dispatch`, generate the environment with `npm run config`, build libs and the
app, upload `dist/<app>` to S3 and invalidate CloudFront. They use repository secrets
`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_REGION_NAME` (UAT) and the `PROD_`-prefixed
equivalents, and variables such as `EQUIPE_SERVICE_URL` / `PROD_EQUIPE_SERVICE_URL`.
They also contain a no-op step (`cd projects/libs` in its own step); do not copy it.

## Current code (read first)

- `.github/workflows/uat-build-client.yml`, `.github/workflows/prod-build-client.yml`
- `setenv.ts` (new variables from S11), `infra/README.md` (S13)

## Tasks

1. `uat-infra-renewal.yml` and `prod-infra-renewal.yml` (`workflow_dispatch`):
   checkout → Node 20.19.0 → `aws-actions/configure-aws-credentials@v4` with the existing
   secrets → `npm ci` in `infra/` → `npx cdk diff -c env=<env>` → `npx cdk deploy --all -c env=<env> --require-approval never`.
   PROD: use a GitHub `environment: production` so the run needs a reviewer.
2. `uat-build-renewal.yml` and `prod-build-renewal.yml` (`workflow_dispatch`):
   - Same `env:` block as the client pipeline plus `RENEWAL_APP_ID_PROVIDER_CLIENT_ID`,
     `RENEWAL_APP_LOGOUT_URL` (`PROD_` variants for PROD); `TEST_MODE` true for UAT, false for PROD.
   - Steps: checkout → Node 20.19.0 → `npm ci` → `npm run config` → `npm run build libs`
     (working directory `projects/libs` set on the step, or run from root as the repo supports)
     → `npm run build:renewal` → configure AWS credentials → upload:
     ```bash
     aws s3 sync dist/renewal/browser "s3://$BUCKET" --delete \
       --exclude index.html --cache-control "public,max-age=31536000,immutable"
     aws s3 cp dist/renewal/browser/index.html "s3://$BUCKET/index.html" \
       --cache-control "no-cache"
     aws cloudfront create-invalidation --distribution-id "$DISTRIBUTION" --paths /index.html
     ```
     Confirm the real output folder (`dist/renewal` or `dist/renewal/browser`) from the Angular builder and use it.
   - `BUCKET` from variable `RENEWAL_S3_BUCKET_NAME` / `PROD_RENEWAL_S3_BUCKET_NAME`,
     `DISTRIBUTION` from `RENEWAL_DISTRIBUTION` / `PROD_RENEWAL_DISTRIBUTION`.
   - PROD uses `environment: production`.
3. Add a short section to the repo README listing the new variables and the order: infra first, then build.

## Acceptance criteria

- The four workflows pass `actionlint` (run it locally or in a lint job).
- No secret value appears in any file; only `${{ secrets.* }}` and `${{ vars.* }}` references.
- The build workflow uploads hashed assets with the long cache header and `index.html` with `no-cache`, then invalidates `/index.html` only.
- PROD workflows require the `production` environment.
- A dry run in UAT (developer) deploys the stack and serves the app at `https://renew-test.nextgen.arzamed.com`.

## Guardrails

- Keep using the existing stored key secrets; OIDC is out of scope.
- Use maintained actions (`actions/checkout@v4`, `actions/setup-node@v4`, `aws-actions/configure-aws-credentials@v4`) instead of third-party upload/invalidation actions.
- Do not modify the existing client/admin/patient workflows.

## Out of scope

OIDC roles. Automatic triggers on push. Backend pipelines (unchanged services use their existing pipelines).

## Definition of done

Workflows committed, `actionlint` clean, README updated, UAT dry run done by a developer.
