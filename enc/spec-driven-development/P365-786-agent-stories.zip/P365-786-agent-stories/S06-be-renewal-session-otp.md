# S06 · [BE] Renewal session and email OTP step-up (user-service, otp-service)

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365` / `user-service`, `otp-service`, `arzamed-rest-client` |
| Depends on | — |
| Size | M |
| **Blocked by** | **Q2**: OTP rule. Working assumption below; edit this story if the answer differs. |

## User story

As an equipe admin signing in to the renewal app, I want to prove it is me with a second factor,
using my authenticator app if I set one up or an emailed code if I did not, so that nobody can
renew or pay with just my password.

## Working assumption (Q2)

- If the user has Cognito TOTP enabled, Cognito already challenged them at sign-in; no extra step.
- Otherwise the user must enter a code sent by email before any renewal action.
- Verification lasts for one sign-in session and is enforced on the server (S07).

## Design

- A **renewal session** is identified by the token claims `sub` + `auth_time`. Both claims are
  present, with the same values, in the Cognito ID token and access token of one sign-in.
- Verified sessions are stored in Redis: key `renewal:stepup:{sub}:{auth_time}`, value `"1"`,
  TTL = the presented token's `exp - now` (minimum 60 s).
- Codes are generated and validated by `otp-service` (`/otp/create`, `/otp/validate`, 5-minute
  expiry, max 3 per hour) and emailed with the existing `EmailService.sendUserOtpEmail(UserDto)`.

## Current code (read first)

- `user-service/src/main/java/com/arzamed/user/service/MfaService.java`, `impl/CognitoMfaService.java` (`showMfaStatus(accessToken)`), `impl/LocalMfaService.java` (profile `dev-local`)
- `user-service/src/main/java/com/arzamed/user/resource/impl/MfaController.java` (how the token is read)
- `user-service/src/main/java/com/arzamed/user/service/impl/OtpServiceImpl.java` (`getOtp`, `verifyOtp` via `OtpClient`)
- `user-service/src/main/java/com/arzamed/user/service/impl/EmailServiceImpl.java` (`sendUserOtpEmail`)
- `user-service/src/main/java/com/arzamed/user/config/RedisConfiguration.java`, `SecurityConfiguration.java`
- `user-service/src/main/java/com/arzamed/user/resource/impl/InternalUserController.java` (internal endpoint style)
- `otp-service/src/main/java/com/arzamed/otp/service/impl/OtpServiceImpl.java` (`createRandomOneTimePassword`)

## Tasks

1. **otp-service hardening**: replace `java.util.Random` with a single `SecureRandom` instance
   in `createRandomOneTimePassword`. Keep 8 digits; make sure codes keep leading zeros
   (today `Integer.parseInt` drops them, so some codes have fewer than 8 digits). Return the
   code as a `String`; update `OneTimePassword.setOtpCode` callers accordingly.
2. **user-service endpoints** (OpenAPI `user-service.yaml`, tag `renewal`):
   ```yaml
   /user/renewal/session:
     post:
       operationId: startRenewalSession
       description: Call with the ACCESS token. Records the session as verified when TOTP is enabled; otherwise emails a code.
       responses:
         '200': { content: { application/json: { schema: { $ref: '#/components/schemas/RenewalSessionDto' } } } }
         '429': { description: Too many codes requested; try again later }
   /user/renewal/session/verify:
     post:
       operationId: verifyRenewalSession
       requestBody: { required: true, content: { application/json: { schema: { $ref: '#/components/schemas/VerifyRenewalSessionRequest' } } } }
       responses:
         '200': { content: { application/json: { schema: { $ref: '#/components/schemas/RenewalSessionDto' } } } }
         '400': { description: Code missing or wrong format }
         '401': { description: Code invalid or expired }
   /api/v1/internal/user/renewal/step-up:
     post:
       operationId: checkRenewalStepUp
       requestBody: { required: true, content: { application/json: { schema: { $ref: '#/components/schemas/RenewalStepUpRequest' } } } }
       responses:
         '200': { content: { application/json: { schema: { $ref: '#/components/schemas/RenewalStepUpResponse' } } } }
   components:
     schemas:
       RenewalSessionDto:            { type: object, required: [verified, otpRequired], properties: { verified: { type: boolean }, otpRequired: { type: boolean } } }
       VerifyRenewalSessionRequest:  { type: object, required: [code], properties: { code: { type: string, pattern: '^\d{8}$' } } }
       RenewalStepUpRequest:         { type: object, required: [sub, authTime], properties: { sub: { type: string }, authTime: { type: integer, format: int64 } } }
       RenewalStepUpResponse:        { type: object, required: [verified], properties: { verified: { type: boolean } } }
   ```
3. `RenewalSessionService` (+ impl):
   - `start(Jwt jwt)`: if already verified → `{verified: true, otpRequired: false}`.
     Else if `mfaService.showMfaStatus(jwt.getTokenValue())` → store marker, return verified.
     Else request a code; if `otp-service` returns no code (rate limit) → `429`; else
     `sendUserOtpEmail(user)` and return `{verified: false, otpRequired: true}`.
   - `verify(Jwt jwt, String code)`: `otpService.verifyOtp(email, code)`; on success store the
     marker and return verified; else `401`.
   - **Resolving the email:** Cognito access tokens carry no `email` claim. Use the token's
     `email` claim when present (local Keycloak); otherwise add
     `Optional<String> findEmail(String accessToken)` to `MfaService`, implemented in
     `CognitoMfaService` from the `email` attribute of `cognitoClient.getUser(...)` (the call
     `showMfaStatus` already makes), and from the claim in `LocalMfaService`.
   - `isVerified(sub, authTime)` for the internal endpoint.
   - Add a `StringRedisTemplate`-based `ValueOperations<String, String>` bean if none exists.
4. Put `RenewalStepUpRequest`/`Response` and an `@HttpExchange` method `checkRenewalStepUp` on
   the existing user client in `arzamed-rest-client` (`com.arzamed.rest.dto.user`), for S07.
5. `SecurityConfiguration`: the internal path stays under the `@Order(1)` internal chain; the two
   public paths use the authenticated JWT chain.
6. Audit: log `RENEWAL_STEPUP_VERIFIED` and failed verifications through the existing activity
   logger used by user-service (email and outcome; never the code).

## Acceptance criteria

- Given a user with TOTP enabled, `POST /user/renewal/session` returns `verified = true` and sends no email.
- Given a user without TOTP, it returns `otpRequired = true` and exactly one OTP email is sent.
- Given a fourth code request within an hour, the response is `429`.
- Given the correct code, `/verify` returns `verified = true` and the Redis key exists with a TTL no longer than the token's remaining lifetime.
- Given a wrong or expired code, `/verify` returns `401` and no key is written.
- The internal endpoint returns `verified = true` only for the exact `sub` + `authTime` pair; a new sign-in (new `auth_time`) is not verified.
- `otp-service` codes are always exactly 8 digits and generated with `SecureRandom`.

## Tests

- `otp-service`: `OtpServiceImplTest` for length/leading zeros (seeded or repeated generation).
- `user-service`: `RenewalSessionServiceImplTest` (`@MockitoBean MfaService, OtpService, EmailService`, Redis mocked or embedded), `RenewalSessionControllerTest` for status codes, internal endpoint test.

## Guardrails

- Never log or return the OTP code. Never log tokens.
- Do not change the existing `/user/mfa/*` endpoints or registration/password-reset OTP flows, except for the code-format fix in otp-service (check their tests still pass).
- OpenAPI first, then regenerate. Conventions from `CLAUDE.md`.

## Out of scope

Enforcing the marker in other services (S07). Frontend (S12).

## Definition of done

`mvn -B package -pl otp-service,user-service,arzamed-rest-client -am` passes.
