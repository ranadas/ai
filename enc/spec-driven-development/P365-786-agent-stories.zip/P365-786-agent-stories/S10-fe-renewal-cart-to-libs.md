# S10 · [FE] Move the renewal cart into libs

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365-web` / `projects/libs`, `projects/client` |
| Depends on | API-plan work merged to `main` (design decision D11) |
| Size | M |

## User story

As a frontend developer, I want the renewal cart to be a shared, store-free component in `libs`,
so that the client app and the new renewal app show the same cart from one source.

## Context

`projects/client/src/app/features/equipe/components/renewal-cart/renewal-cart.component.ts`
(≈320 lines) mixes three things: presentation (edition and API plan radio lists, totals),
data loading (NgRx selectors, `SubscriptionService.getRenewalQuote`, `ClientApiClientService`),
and the pay flow (set pending API plan, then dispatch `payNextSubscription` or `upgradeDowngrade`
and redirect). It depends on `AppState`, `CommonService`, `UIActions` and the client router, so
it cannot be used outside the client app.

## Target structure

```
projects/libs/src/lib/renewal/
  renewal-cart/renewal-cart.component.{ts,html,scss}   // presentational, OnPush
  renewal-checkout.service.ts                          // stateless, HttpClient-based
  renewal-cart.models.ts                               // view-model types
projects/client/src/app/features/equipe/components/renewal-cart/
  renewal-cart.component.ts                            // thin container (keeps selector app-renewal-cart)
```

### Presentational component (libs)

```ts
@Component({ selector: 'lib-renewal-cart', standalone: true,
             changeDetection: ChangeDetectionStrategy.OnPush, ... })
export class RenewalCartComponent {
  editions        = input.required<EquipeEdition[]>();   // isMaxUserExceeded → disabled option + support message
  currentEditionId = input.required<string>();
  apiPlans        = input<UsagePlanDto[]>([]);           // empty → API plan section hidden
  currentApiPlan  = input<string | null>(null);
  quote           = input<RenewalQuoteDto | null>(null);
  busy            = input(false);

  editionChange   = output<string>();                    // container reloads the quote
  pay             = output<RenewalSelection>();          // { editionId, apiPlan: string | null }
}
```

- Totals and prices come from `quote()` and `apiPlans()` exactly as today (`totalToday` logic, "Nessuno" → no plan).
- The "expires on" date uses `quote().termEnd` when present; fall back to today + 1 year only when it is absent (today the component always uses today + 1 year, which is wrong for renewals).
- No `Store`, `Router`, `CommonService`, toasts or `window.location` inside libs.

### Stateless service (libs)

```ts
@Injectable({ providedIn: 'root' })
export class RenewalCheckoutService {
  quote(equipeId: string, editionId: string): Observable<RenewalQuoteDto>;
  editions(equipeId: string): Observable<EquipeEdition[]>;
  apiPlans(): Observable<UsagePlanDto[]>;
  /** Sets the pending API plan if it changed, then returns the Stripe checkout URL. */
  checkout(equipeId: string, current: RenewalSelection, selected: RenewalSelection,
           returnTarget: 'CLIENT' | 'RENEWAL'): Observable<string>;
}
```

`checkout` keeps today's ordering: the pending-plan call must complete before the payment call
starts. It picks `getSubscriptionPaymentLink` when the edition is unchanged and
`changeEditionAtSubscriptionRenewal` (with `UpgradeDowngradeEnum` from list order, as today) when
it changed, passing `returnTarget` (added in S04; regenerate the libs API client from the
updated `equipe-service.yaml`).

## Current code (read first)

- `projects/client/src/app/features/equipe/components/renewal-cart/renewal-cart.component.{ts,html,scss}`
- `projects/client/src/app/features/equipe/components/renewal/renewal.component.ts` (how the cart is opened)
- `projects/client/src/app/state/equipe/equipe-api.effects.ts` (`payNextSubscription`, `upgradeDowngrade` effects)
- `projects/libs/src/public-api.ts`, `projects/libs/src/lib/components/` (existing shared components such as `RadioListComponent`, `PageTopComponent`)
- `projects/libs/src/lib/api/equipe/services/subscription.service.ts`, `projects/libs/src/lib/api/apikey/...` (generated clients)

## Tasks

1. Create the libs files above; export them from `public-api.ts`.
2. Move template and styles into the libs component; keep Italian copy and CSS classes identical.
3. Rewrite the client component as a container: it gathers inputs from the store and
   `CommonService`, calls `RenewalCheckoutService.checkout(..., 'CLIENT')`, shows the existing
   toast on error, and redirects with `window.location.href`. Remove the cart-specific NgRx
   effects only if nothing else uses them.
4. Regenerate the libs API clients for S03/S04 contract changes (`termStart`, `termEnd`,
   `eligibility`, `returnTarget`, `renewal-status`) using the repo's existing generator setup.

## Acceptance criteria

- The client app's renewal cart looks and behaves exactly as before for an `EXPIRING` equipe (same options, totals, disabled editions, pay flow, error toast).
- `lib-renewal-cart` renders with only inputs set (no providers other than `CommonModule`/forms).
- When `apiPlans` is empty, the API plan section is not rendered.
- When `quote.termEnd` is set, the displayed expiry date equals it.
- `checkout` never starts the payment request before the pending-plan request completes (test with a delayed observable).

## Tests

- `renewal-cart.component.spec.ts` (libs): rendering, disabled editions, API section hidden, `pay` emits the selection.
- `renewal-checkout.service.spec.ts` (libs): endpoint choice, ordering, `returnTarget` passed through (`HttpTestingController`).
- Client container spec: dispatch/redirect wiring. Existing client Cypress renewal tests pass.

## Guardrails

- Angular 18, standalone components, signals `input()`/`output()`, `OnPush`.
- Libraries may not import from `projects/client` or `projects/admin`.
- Do not edit generated files under `libs/src/lib/api` by hand; regenerate them.
- Build libs before apps: `cd projects/libs && npm run build libs`.

## Out of scope

The renewal app itself (S11, S12). Visual redesign.

## Definition of done

`npm run build libs`, `npm run build:client`, and the unit tests pass; client Cypress renewal spec passes.
