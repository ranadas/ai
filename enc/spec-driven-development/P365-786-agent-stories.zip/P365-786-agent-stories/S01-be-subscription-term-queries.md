# S01 · [BE] Subscription term queries and production data check

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365` / `equipe-service`, `plus365-db` (script only) |
| Depends on | — |
| Size | M |

## User story

As a backend developer, I want reliable queries for an equipe's **last term in force** and its
**pending term**, so that renewal logic works the same before and after a subscription expires.

## Context

Today the renewal code finds subscriptions with queries that only work while a term is active:

- `findCurrentSubscription` requires `active_subscription = true` and `CURRENT_DATE BETWEEN start_date AND end_date`.
- `findNextSubscription` requires `start_date >= CURRENT_DATE`.
- The nightly job `disableExpiredEquipes` sets `active_subscription = false` on ended terms.

After expiry both queries return nothing, so the renewal endpoints cannot work. We need two
queries that are correct in every state, and a read-only check of production data that confirms
the predicate below holds.

## Definitions (implement exactly)

- **Pending term**: the row that the next payment will activate.
  `active_subscription = false AND payment_date IS NULL AND end_date > :today`.
  If several rows match (possible in old data), take the one with the latest `start_date`.
- **Term in force** (a term that was actually granted): `payment_date IS NOT NULL`
  **or** it was created without a Stripe checkout (the column written by
  `setPaymentLinkForSubscription` is `NULL`) **and** `is_created_by_system = false`.
  Abandoned upgrades and unpaid system renewals therefore do not count.
- **Last term in force**: the term in force with the latest `end_date`.

`:today` is always passed in as a parameter. Do not use `CURRENT_DATE` in the new queries, so
tests can use a fixed clock.

## Current code (read first)

- `equipe-service/src/main/java/com/arzamed/equipe/mapper/SubscriptionMapper.java`
  (`findCurrentSubscription`, `findNextSubscriptionToActivate`, `findNextSubscription`,
  `findAllExpiredAndYetActiveEquipes`, `disableExpiredEquipe`, `setPaymentLinkForSubscription`)
- `equipe-service/src/main/java/com/arzamed/equipe/service/impl/SubscriptionServiceImpl.java`
  (`createNextSubscriptionForExpiringEquipes`)
- `equipe-service/src/test/java/com/arzamed/equipe/mapper/SubscriptionMapperTest.java`
- `equipe-service/src/test/resources/application-test.yaml` and the H2 schema/data it loads

## Tasks

1. Add to `SubscriptionMapper` (annotation-based SQL, text blocks, reuse the existing
   `equipeSubscriptionDto` result map):
   - `Optional<EquipeSubscriptionDto> findLastTermInForce(String equipeId, LocalDate today)`
   - `Optional<EquipeSubscriptionDto> findPendingTerm(String equipeId, LocalDate today)`
   - `Optional<String> lockEquipe(String equipeId)`: `SELECT id FROM EQUIPE WHERE id = #{equipeId}::uuid FOR UPDATE`.
     Used by S02 to serialise pending-term creation per equipe.
2. Do **not** change or delete the existing queries; S02 switches callers over.
3. Add a read-only SQL script `plus365-db/src/main/script/p365-786-data-check.sql` that reports,
   for production:
   - equipes with more than one pending term (per the definition above, `:today = CURRENT_DATE`);
   - equipes whose latest row by `end_date` is **not** a term in force, with the row's flags;
   - count of terms in force with `payment_date IS NULL` (admin-created) vs not;
   - equipes with no term in force at all.
   Each query has a comment explaining what a non-empty result means.

## Acceptance criteria

- Given an equipe whose paid term ended yesterday and was disabled by `disableExpiredEquipe`,
  when `findLastTermInForce(equipeId, today)` runs, then it returns that term.
- Given the same equipe with a system-created unpaid row starting at the old end date,
  when `findPendingTerm` runs, then it returns that row.
- Given an abandoned mid-subscription upgrade (unpaid, `is_created_by_system = false`, has a
  checkout session id), when `findLastTermInForce` runs, then the upgrade row is ignored.
- Given an admin-created initial term (no payment date, no checkout session), then it counts as in force.
- Given an unpaid row whose `end_date <= today`, then `findPendingTerm` ignores it.
- Given two pending rows, `findPendingTerm` returns the one with the latest `start_date`.
- `lockEquipe` runs on H2 and PostgreSQL.

## Tests

`SubscriptionMapperTest` (H2): one test per acceptance criterion, each inserting its own rows.
Use explicit dates relative to a fixed `today` (for example `2026-10-01`).

## Guardrails

- MyBatis only; `map-underscore-to-camel-case` is on.
- Keep SQL portable between PostgreSQL and H2 (the existing `::uuid` casts are fine).
- Checkstyle and licence header rules from `CLAUDE.md`.

## Out of scope

Changing service logic or endpoints (S02). Any schema change.

## Definition of done

- `mvn -B package -pl equipe-service -am` passes.
- The data-check script runs against a local PostgreSQL loaded with `docker compose up -d`
  without errors, and its header explains how to run it read-only in UAT/PROD.
- PR description includes the script output from UAT (run by a developer, not the agent).
