# S09 · [BE] apikey-service support for expired equipes

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365` / `apikey-service`, `arzamed-rest-client` |
| Depends on | S02, S07 |
| Size | M |
| **Blocked by** | **Q1**: can an admin change the API plan when renewing an expired plan? This story assumes **yes**. If the answer is **no**, replace it with: "cart hides the API plan selector for expired equipes; quote keeps the current plan" (frontend only, in S12). |

## User story

As the admin of an expired equipe that uses the external API, I want to keep or change my API
plan in the same renewal, so that my integration works again once I pay.

## Context

- `setPendingPlan` (`ApiClientServiceImpl`) refuses when `renewalDate - today > 15` days. For an
  expired equipe the difference is negative, so the check already passes, provided
  `apiClientMapper.findActiveByEquipeId` finds a key (`api_client.active = true`). Keys are not
  deactivated when a subscription expires, so this normally holds; confirm it.
- After payment, equipe-service calls `applyPendingPlanNow(equipeId)`. A daily reconcile job
  (`/api/v1/internal/api-client/reconcile-renewal-dates`) re-pins `renewal_date` from the
  subscription end date. Both must give the right result when the new term started in the past
  (`EXPIRED_RECENT`) or starts on payment (`EXPIRED_LONG`, S08).
- `renewal-quote` (equipe-service) reads `getRenewalInfo(equipeId)`; `hasActivePlan` must be true for an expired equipe that still has an active key.

## Current code (read first)

- `apikey-service/src/main/java/com/arzamed/apikey/service/impl/ApiClientServiceImpl.java` — `setPendingPlan`, `applyPendingPlanNow`, `getRenewalInfo`, `renewApiKeyDate`, the reconcile method
- `apikey-service/src/main/java/com/arzamed/apikey/mapper/ApiClientMapper.java` — `findActiveByEquipeId`, `findWithFutureRenewalByEquipeId`, `applyPendingPlanNow`
- `apikey-service/src/main/java/com/arzamed/apikey/resource/impl/InternalApiClientController.java`
- `apikey-service/src/main/resources/apikey-service.yaml` — `/client/api-client/pending-plan`
- `equipe-service/.../StripeWebhookServiceImpl.java` (the `applyPendingPlanNow` call after activation)

## Tasks

1. Make the eligibility explicit instead of relying on a negative day count: `setPendingPlan`
   allows the change when `renewalDate` is within 15 days **or in the past**. Keep the error
   message for the far-future case.
2. Step-up: when the equipe's API term has lapsed (`renewalDate < today`), require a verified
   renewal session (same internal `checkRenewalStepUp` call as S07; share the verifier through
   `arzamed-rest-client` if practical, otherwise copy the small class). `403 STEP_UP_REQUIRED` otherwise.
3. Verify and, if needed, fix `applyPendingPlanNow` and the reconcile job so that after the
   webhook `renewal_date` equals the **new** term's end date for `EXPIRED_RECENT` (end = old end + 1 year) and `EXPIRED_LONG` (end = payment day + 1 year).
4. `getRenewalInfo` returns `hasActivePlan = true` for an expired equipe with an active key.

## Acceptance criteria

- Given an expired equipe with an active key, `PATCH /client/api-client/pending-plan` by a verified admin succeeds and stores the pending plan.
- Given the same call from an unverified session, the response is `403 STEP_UP_REQUIRED`.
- Given a renewal date 40 days away, the call is still refused (unchanged).
- Given an `EXPIRED_RECENT` renewal is paid, after `applyPendingPlanNow` and one reconcile run the key's `usage_plan` is the pending plan and `renewal_date` is the new term's end date.
- `renewal-quote` for that equipe includes the API plan amount.

## Tests

`ApiClientServiceImplTest` (fixed clock for past/near/far renewal dates, step-up mocked), mapper test for any changed query, and an equipe-service webhook test asserting `applyPendingPlanNow` is called for expired renewals.

## Guardrails

Do not change key generation, secrets or usage metering. OpenAPI first, then regenerate. Conventions from `CLAUDE.md`.

## Out of scope

API plan upgrades during an active term. Frontend.

## Definition of done

`mvn -B package -pl apikey-service,equipe-service -am` passes.
