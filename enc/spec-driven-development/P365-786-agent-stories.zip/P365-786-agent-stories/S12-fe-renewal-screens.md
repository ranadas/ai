# S12 · [FE] Renewal app screens and flow

| | |
|---|---|
| Epic | P365-786 |
| Repo / module | `plus365-web` / `projects/renewal` |
| Depends on | S10, S11; backend contracts from S03, S04, S05, S06, S07 (can be built against mocks first) |
| Size | L |

## User story

As the admin of an expired equipe, I want to sign in, verify it's me, pick my equipe, choose my
edition, pay and be signed out, so that my equipe's access is restored without contacting support.
As a non-admin member, I want to see who can renew for my equipe.

## Screens (all Italian copy; wording below is the English intent)

| Route | Behaviour |
|---|---|
| `/verify` | Shown when `POST /user/renewal/session` returned `otpRequired`. Text: a code was sent to the user's email. 8-digit input (numeric keyboard, paste allowed), "Verify" button, "Send a new code" link (disabled for 60 s after each send). `401` → "The code is wrong or has expired." `429` → "Too many codes requested. Try again in an hour." On success → `/equipes`. |
| `/equipes` | `GET /user/renewal/equipes`. None → message "You have no expired equipes" + sign-out button. Exactly one with `canRenew` and no others → go straight to `/renew/:id`. Otherwise a list; `canRenew` items go to `/renew/:id`, others to `/contact-admin/:id`. |
| `/renew/:equipeId` | First `GET renewal-status`: `PAYMENT_PENDING` or `PAID` → `/payment-pending/:id`. Else load editions, API plans (hidden if Q1 = no), quote; render `lib-renewal-cart` (S10). Show "Your new term: {termStart} – {termEnd}". `editionChange` reloads the quote. `pay` → `RenewalCheckoutService.checkout(..., 'RENEWAL')` → `window.location.href = url`. `?cancelled=1` → info banner "Payment cancelled. Nothing was charged." `409 PAYMENT_PENDING` → `/payment-pending/:id`. |
| `/contact-admin/:equipeId` | `GET /user/renewal/equipes/{id}/admins`. "Only these people can renew {equipe}:" followed by first + last names. Sign-out button. Empty list → "Contact ArzaMed support" with support email shown as text. |
| `/payment-pending/:equipeId` | "Your payment is being processed. Access returns when it arrives; you'll get a confirmation email." Sign-out button. |
| `/thanks` | Stripe `success_url`. "Thank you. Your payment has been received and is being processed; you'll get a confirmation email." Then sign-out automatically after 8 s, with a "Sign out now" button. Works without a valid token (tokens may have expired during checkout). |
| `/signed-out` | Static: "You have been signed out." Link to `https://app.nextgen.arzamed.com` shown as text + link (value from environment). |

Wording follows D5 (card + bank transfer): never promise that access is already restored.

## Current code (read first)

- `projects/renewal/**` (S11 scaffold: routes, guards, `RenewalAuthService`, interceptor)
- `projects/libs/src/lib/renewal/**` (S10: `RenewalCartComponent`, `RenewalCheckoutService`)
- `projects/libs/src/lib/api/user/**`, `.../equipe/**` (regenerated clients for S03–S06)
- `projects/client/src/app/no-auth/payment-done/*` (existing thank-you page style)

## Tasks

1. Build the screens above as standalone components with signals; one small `RenewalFlowStore`
   service (signals) holds the equipes list and the step-up result for the session.
2. Loading, empty and error states on every screen; errors show a retry action.
3. Accessibility: labelled inputs, focus moves to the page title on navigation, error messages
   linked with `aria-describedby`, visible focus styles.
4. Cypress e2e specs with intercepted API calls (`cy.intercept`) for each flow below.

## Acceptance criteria (Cypress, API mocked)

1. User with TOTP (`verified: true`) and one renewable expired equipe → lands on `/renew/:id` without seeing `/verify` or `/equipes`.
2. User without TOTP → `/verify`; wrong code shows the error; right code → `/equipes`.
3. Two expired equipes, one renewable → list shows both; the other opens `/contact-admin/:id` with names only.
4. Pay → `checkout` called with `returnTarget = RENEWAL` → browser navigates to the returned URL.
5. `renewal-status = PAYMENT_PENDING` → `/payment-pending/:id`; no cart shown.
6. Return with `?cancelled=1` → banner shown, cart usable.
7. `/thanks` with no token → message shown, then `/signed-out`; with token → refresh-token revocation request sent, then IdP logout.
8. Any API `403 STEP_UP_REQUIRED` → `/verify`.

## Guardrails

- No business rules in the frontend: eligibility, dates and prices come from the API.
- No NgRx; no imports from `projects/client`.
- Keep bundle small: lazy-load `/renew` (it pulls the cart and forms).
- Italian text in templates; keep strings in one constants file per screen for later i18n.

## Out of scope

Backend. Infrastructure. Visual redesign of the cart.

## Definition of done

`npm run build:renewal` passes; unit tests and the Cypress specs above pass locally
(`cypress run --project projects/renewal` or the repo's equivalent script).
