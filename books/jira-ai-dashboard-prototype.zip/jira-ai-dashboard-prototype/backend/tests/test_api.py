from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_query_returns_widgets():
    response = client.post("/api/query", json={"prompt": "Show open issues by priority"})
    assert response.status_code == 200
    body = response.json()
    assert body["source"] == "mock"
    assert any(widget["type"] == "chart" for widget in body["widgets"])
    assert any(widget["type"] == "table" for widget in body["widgets"])
