from __future__ import annotations

from collections import Counter

from .jira_provider import JiraIssue, JiraProvider
from .models import ChartWidget, DashboardResponse, MetricWidget, Series, TableWidget, TextWidget

MONTHS = ["Apr", "May", "Jun", "Jul", "Aug", "Sep"]


class DashboardService:
    def __init__(self, jira: JiraProvider) -> None:
        self.jira = jira

    async def answer(self, prompt: str) -> DashboardResponse:
        # In a production agent, an LLM can create JQL/tool arguments here.
        # The prototype preserves the security boundary by producing a read-only query.
        query_used = self._query_for_prompt(prompt)
        issues = await self.jira.search_issues(query_used)
        widgets = self._plan_widgets(prompt, issues)

        open_count = sum(1 for i in issues if i.status != "Done")
        p1_open = sum(1 for i in issues if i.status != "Done" and i.priority == "P1")
        summary = (
            f"Analysed {len(issues)} issues. {open_count} are unresolved, including {p1_open} P1 issue"
            f"{'s' if p1_open != 1 else ''}. The dashboard below is generated from a constrained widget schema."
        )

        return DashboardResponse(
            title="Jira analytics",
            summary=summary,
            source=self.jira.source_name,  # type: ignore[arg-type]
            query_used=query_used,
            widgets=widgets,
        )

    def _query_for_prompt(self, prompt: str) -> str:
        lower = prompt.lower()
        if "priority" in lower or "p1" in lower or "p2" in lower:
            return "project = APP AND created >= -180d ORDER BY priority ASC, created DESC"
        if "team" in lower:
            return "project = APP AND created >= -180d ORDER BY created DESC"
        return "project = APP AND created >= -180d ORDER BY created ASC"

    def _plan_widgets(self, prompt: str, issues: list[JiraIssue]):
        lower = prompt.lower()
        open_issues = [i for i in issues if i.status != "Done"]

        metrics = [
            MetricWidget(title="Issues analysed", value=len(issues), subtitle="Last 6 months"),
            MetricWidget(title="Unresolved", value=len(open_issues), subtitle="Open + in progress"),
            MetricWidget(title="Open P1", value=sum(1 for i in open_issues if i.priority == "P1"), subtitle="Needs attention"),
        ]

        if "priority" in lower or "p1" in lower or "p2" in lower:
            counts = Counter(i.priority for i in open_issues)
            chart = ChartWidget(
                chart_type="bar",
                title="Unresolved issues by priority",
                categories=["P1", "P2", "P3"],
                series=[Series(name="Issues", data=[counts.get("P1", 0), counts.get("P2", 0), counts.get("P3", 0)])],
            )
            return [*metrics, chart, self._issue_table(open_issues)]

        if "status" in lower or "distribution" in lower:
            counts = Counter(i.status for i in issues)
            chart = ChartWidget(
                chart_type="pie",
                title="Issue status distribution",
                categories=["Open", "In Progress", "Done"],
                series=[Series(name="Issues", data=[counts.get("Open", 0), counts.get("In Progress", 0), counts.get("Done", 0)])],
            )
            return [*metrics, chart, self._issue_table(issues)]

        if "team" in lower:
            counts = Counter(i.team for i in open_issues)
            teams = sorted(counts, key=lambda team: counts[team], reverse=True)
            chart = ChartWidget(
                chart_type="bar",
                title="Unresolved issues by team",
                categories=teams,
                series=[Series(name="Issues", data=[counts[t] for t in teams])],
            )
            return [*metrics, chart, self._issue_table(open_issues)]

        if "table" in lower or "underlying" in lower or "issues" in lower and "show" in lower:
            # Keep the trend chart too, because it demonstrates mixed widget composition.
            return [*metrics, self._trend_chart(issues), self._issue_table(issues)]

        return [
            *metrics,
            self._trend_chart(issues),
            TextWidget(
                title="What this prototype demonstrates",
                body="The backend decides what data is allowed and returns validated widget JSON. Angular owns all HTML and visualization rendering.",
            ),
            self._issue_table(open_issues),
        ]

    def _trend_chart(self, issues: list[JiraIssue]) -> ChartWidget:
        opened = Counter(i.created_month for i in issues)
        closed = Counter(i.resolved_month for i in issues if i.resolved_month)
        return ChartWidget(
            chart_type="line",
            title="Issues opened vs closed",
            categories=MONTHS,
            series=[
                Series(name="Opened", data=[opened.get(month, 0) for month in MONTHS]),
                Series(name="Closed", data=[closed.get(month, 0) for month in MONTHS]),
            ],
        )

    def _issue_table(self, issues: list[JiraIssue]) -> TableWidget:
        return TableWidget(
            title="Underlying Jira issues",
            columns=["Key", "Summary", "Status", "Priority", "Team"],
            rows=[[i.key, i.summary, i.status, i.priority, i.team] for i in issues],
        )
