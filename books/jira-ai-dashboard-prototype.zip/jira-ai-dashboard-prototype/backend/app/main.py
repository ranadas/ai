from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .dashboard_service import DashboardService
from .jira_provider import get_jira_provider
from .models import DashboardResponse, QueryRequest

app = FastAPI(title="Jira AI Dashboard Prototype", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4200"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
async def health():
    provider = get_jira_provider()
    return {"status": "ok", "jiraProvider": provider.source_name}


@app.post("/api/query", response_model=DashboardResponse)
async def query(request: QueryRequest) -> DashboardResponse:
    try:
        service = DashboardService(get_jira_provider())
        return await service.answer(request.prompt)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
