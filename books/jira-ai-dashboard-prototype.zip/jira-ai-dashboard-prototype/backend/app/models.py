from __future__ import annotations

from typing import Literal, Union
from pydantic import BaseModel, Field


class QueryRequest(BaseModel):
    prompt: str = Field(min_length=2, max_length=2000)


class MetricWidget(BaseModel):
    type: Literal["metric"] = "metric"
    title: str
    value: int | float | str
    subtitle: str | None = None


class Series(BaseModel):
    name: str
    data: list[float]


class ChartWidget(BaseModel):
    type: Literal["chart"] = "chart"
    chart_type: Literal["line", "bar", "pie"]
    title: str
    categories: list[str]
    series: list[Series]


class TableWidget(BaseModel):
    type: Literal["table"] = "table"
    title: str
    columns: list[str]
    rows: list[list[str | int | float]]


class TextWidget(BaseModel):
    type: Literal["text"] = "text"
    title: str
    body: str


Widget = Union[MetricWidget, ChartWidget, TableWidget, TextWidget]


class DashboardResponse(BaseModel):
    title: str
    summary: str
    source: Literal["mock", "mcp"]
    query_used: str
    widgets: list[Widget]
