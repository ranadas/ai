from __future__ import annotations

import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date
from typing import Any

from mcp import Client


@dataclass
class JiraIssue:
    key: str
    summary: str
    status: str
    priority: str
    team: str
    created_month: str
    resolved_month: str | None


class JiraProvider(ABC):
    source_name: str

    @abstractmethod
    async def search_issues(self, query: str) -> list[JiraIssue]:
        raise NotImplementedError


class MockJiraProvider(JiraProvider):
    source_name = "mock"

    async def search_issues(self, query: str) -> list[JiraIssue]:
        # Deterministic demo data. It intentionally resembles normalized Jira output,
        # not Jira's raw REST response, so the rest of the app is provider-neutral.
        return [
            JiraIssue("APP-101", "Login fails after timeout", "Done", "P1", "Platform", "Apr", "Apr"),
            JiraIssue("APP-102", "Search indexing lag", "Done", "P2", "Platform", "Apr", "May"),
            JiraIssue("APP-103", "CSV export formatting", "Done", "P3", "Experience", "Apr", "Apr"),
            JiraIssue("APP-104", "Mobile navigation overlap", "Done", "P2", "Experience", "May", "May"),
            JiraIssue("APP-105", "Webhook retries duplicated", "In Progress", "P1", "Integrations", "May", None),
            JiraIssue("APP-106", "Audit table is slow", "Done", "P2", "Platform", "May", "Jun"),
            JiraIssue("APP-107", "Jira sync misses labels", "Open", "P2", "Integrations", "Jun", None),
            JiraIssue("APP-108", "Dark mode contrast", "Done", "P3", "Experience", "Jun", "Jun"),
            JiraIssue("APP-109", "SSO group mapping", "In Progress", "P1", "Platform", "Jun", None),
            JiraIssue("APP-110", "Date picker timezone issue", "Done", "P2", "Experience", "Jul", "Jul"),
            JiraIssue("APP-111", "Rate limit telemetry", "Open", "P2", "Integrations", "Jul", None),
            JiraIssue("APP-112", "Dashboard query timeout", "In Progress", "P1", "Platform", "Jul", None),
            JiraIssue("APP-113", "Bulk edit accessibility", "Open", "P3", "Experience", "Aug", None),
            JiraIssue("APP-114", "Connector auth refresh", "Done", "P1", "Integrations", "Aug", "Aug"),
            JiraIssue("APP-115", "Duplicate notifications", "Open", "P2", "Platform", "Aug", None),
            JiraIssue("APP-116", "Issue card keyboard focus", "Open", "P3", "Experience", "Sep", None),
            JiraIssue("APP-117", "MCP response pagination", "In Progress", "P2", "Integrations", "Sep", None),
            JiraIssue("APP-118", "Admin report memory spike", "Open", "P1", "Platform", "Sep", None),
        ]


class McpJiraProvider(JiraProvider):
    """Adapter for a Streamable HTTP MCP Jira server.

    The official MCP SDK can connect directly to an MCP URL. Jira MCP servers do
    not all expose the same tool names or argument schemas, so this class keeps
    that mapping in one small place.
    """

    source_name = "mcp"

    def __init__(self) -> None:
        self.server_url = os.environ.get("MCP_SERVER_URL", "http://localhost:9000/mcp")
        self.search_tool = os.environ.get("MCP_JIRA_SEARCH_TOOL", "search_jira_issues")

    async def search_issues(self, query: str) -> list[JiraIssue]:
        async with Client(self.server_url) as client:
            result = await client.call_tool(self.search_tool, {"query": query})

        if result.is_error:
            raise RuntimeError(f"MCP Jira tool '{self.search_tool}' returned an error")

        payload: Any = result.structured_content
        if payload is None:
            raise RuntimeError(
                "The MCP tool did not return structured_content. "
                "Map its content blocks to JiraIssue objects in McpJiraProvider."
            )

        raw_issues = payload.get("issues", payload) if isinstance(payload, dict) else payload
        if not isinstance(raw_issues, list):
            raise RuntimeError("Expected MCP structured content to contain an issue list")

        issues: list[JiraIssue] = []
        for item in raw_issues:
            if not isinstance(item, dict):
                continue
            issues.append(
                JiraIssue(
                    key=str(item.get("key", "UNKNOWN")),
                    summary=str(item.get("summary", "")),
                    status=str(item.get("status", "Unknown")),
                    priority=str(item.get("priority", "Unknown")),
                    team=str(item.get("team", "Unknown")),
                    created_month=str(item.get("created_month", date.today().strftime("%b"))),
                    resolved_month=(str(item["resolved_month"]) if item.get("resolved_month") else None),
                )
            )
        return issues


def get_jira_provider() -> JiraProvider:
    provider = os.environ.get("JIRA_PROVIDER", "mock").lower()
    if provider == "mcp":
        return McpJiraProvider()
    return MockJiraProvider()
