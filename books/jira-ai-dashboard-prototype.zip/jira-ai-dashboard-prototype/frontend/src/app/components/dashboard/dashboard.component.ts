import { Component, Input } from '@angular/core';
import { ChartWidget, DashboardResponse, MetricWidget, TableWidget, TextWidget } from '../../models/dashboard';
import { ChartComponent } from '../chart/chart.component';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [ChartComponent],
  template: `
    <section class="result-head">
      <div>
        <span class="eyebrow">Generated dashboard</span>
        <h2>{{ dashboard.title }}</h2>
        <p>{{ dashboard.summary }}</p>
      </div>
      <span class="source-badge">{{ dashboard.source === 'mock' ? 'Mock Jira' : 'Jira via MCP' }}</span>
    </section>

    <div class="widget-grid">
      @for (widget of dashboard.widgets; track $index) {
        @if (widget.type === 'metric') {
          <article class="card metric">
            <span>{{ asMetric(widget).title }}</span>
            <strong>{{ asMetric(widget).value }}</strong>
            <small>{{ asMetric(widget).subtitle }}</small>
          </article>
        } @else if (widget.type === 'chart') {
          <article class="card chart-card">
            <div class="card-head"><h3>{{ asChart(widget).title }}</h3><span>{{ asChart(widget).chart_type }}</span></div>
            <app-chart [chart]="asChart(widget)" />
          </article>
        } @else if (widget.type === 'table') {
          <article class="card table-card">
            <h3>{{ asTable(widget).title }}</h3>
            <div class="table-scroll"><table><thead><tr>@for (col of asTable(widget).columns; track col) { <th>{{ col }}</th> }</tr></thead>
            <tbody>@for (row of asTable(widget).rows; track $index) { <tr>@for (cell of row; track $index) { <td>{{ cell }}</td> }</tr> }</tbody></table></div>
          </article>
        } @else {
          <article class="card text-card"><h3>{{ asText(widget).title }}</h3><p>{{ asText(widget).body }}</p></article>
        }
      }
    </div>

    <details class="query-details">
      <summary>Show generated Jira query</summary>
      <code>{{ dashboard.query_used }}</code>
    </details>
  `,
  styles: [`
    .result-head { margin: 38px 0 18px; display:flex; justify-content:space-between; gap:20px; align-items:flex-start; }.eyebrow { font-size:11px;text-transform:uppercase;letter-spacing:.11em;font-weight:800;color:var(--accent)}
    h2{margin:6px 0 7px;font-size:30px;letter-spacing:-.03em} .result-head p{margin:0;color:var(--muted);max-width:760px;line-height:1.55}.source-badge{white-space:nowrap;border:1px solid var(--border);background:var(--surface);padding:8px 11px;border-radius:999px;font-size:12px;color:var(--muted)}
    .widget-grid{display:grid;grid-template-columns:repeat(12,1fr);gap:16px}.card{background:var(--surface);border:1px solid var(--border);border-radius:18px;box-shadow:var(--shadow-soft)}
    .metric{grid-column:span 4;padding:20px;display:grid;gap:5px}.metric span{font-size:12px;color:var(--muted);font-weight:700}.metric strong{font-size:32px;letter-spacing:-.04em}.metric small{color:var(--muted)}
    .chart-card{grid-column:span 12;padding:22px}.card-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:15px}.card-head span{font-size:11px;text-transform:uppercase;color:var(--muted);background:var(--surface-2);padding:5px 8px;border-radius:7px}h3{font-size:17px;margin:0 0 16px}
    .table-card{grid-column:span 12;padding:22px}.table-scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th{text-align:left;color:var(--muted);font-weight:700;border-bottom:1px solid var(--border);padding:10px 12px}td{padding:11px 12px;border-bottom:1px solid var(--border)}tbody tr:last-child td{border-bottom:0}
    .text-card{grid-column:span 12;padding:22px}.text-card p{margin:0;color:var(--muted);line-height:1.55}.query-details{margin:16px 0 10px;border:1px solid var(--border);background:var(--surface);border-radius:13px;padding:12px 15px;color:var(--muted);font-size:13px}.query-details code{display:block;margin-top:10px;white-space:pre-wrap;color:var(--text)}
    @media(max-width:720px){.metric{grid-column:span 12}.result-head{flex-direction:column}.source-badge{align-self:flex-start}}
  `]
})
export class DashboardComponent {
  @Input({ required: true }) dashboard!: DashboardResponse;
  asMetric(w: unknown): MetricWidget { return w as MetricWidget; }
  asChart(w: unknown): ChartWidget { return w as ChartWidget; }
  asTable(w: unknown): TableWidget { return w as TableWidget; }
  asText(w: unknown): TextWidget { return w as TextWidget; }
}
