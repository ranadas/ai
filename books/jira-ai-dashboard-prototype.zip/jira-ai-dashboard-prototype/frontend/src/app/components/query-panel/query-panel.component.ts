import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-query-panel',
  standalone: true,
  imports: [FormsModule],
  template: `
    <section class="query-card">
      <div class="query-copy">
        <span class="eyebrow">Natural-language analytics</span>
        <h1>Ask Jira a business question.</h1>
        <p>The backend queries Jira through a provider boundary and returns safe, structured dashboard widgets.</p>
      </div>

      <form (ngSubmit)="submit()" class="query-form">
        <textarea
          [(ngModel)]="prompt"
          name="prompt"
          rows="3"
          [disabled]="loading"
          placeholder="e.g. Show bugs opened vs closed for the last 6 months"></textarea>
        <div class="query-actions">
          <div class="examples">
            @for (example of examples; track example) {
              <button type="button" class="chip" (click)="useExample(example)" [disabled]="loading">{{ example }}</button>
            }
          </div>
          <button class="primary" type="submit" [disabled]="loading || prompt.trim().length < 2">
            {{ loading ? 'Analysing…' : 'Generate dashboard' }}
          </button>
        </div>
      </form>
    </section>
  `,
  styles: [`
    .query-card { padding: 30px; border: 1px solid var(--border); border-radius: 22px; background: linear-gradient(135deg, rgba(92,104,255,.1), rgba(122,78,255,.04)); box-shadow: var(--shadow); }
    .query-copy { max-width: 760px; }
    .eyebrow { font-size: 12px; text-transform: uppercase; letter-spacing: .12em; font-weight: 800; color: var(--accent); }
    h1 { margin: 9px 0 8px; font-size: clamp(30px, 4vw, 48px); letter-spacing: -.04em; line-height: 1.02; }
    p { margin: 0; color: var(--muted); max-width: 700px; line-height: 1.55; }
    .query-form { margin-top: 26px; }
    textarea { width: 100%; resize: vertical; min-height: 96px; box-sizing: border-box; border: 1px solid var(--border); border-radius: 14px; padding: 16px; background: var(--surface); color: var(--text); font: inherit; font-size: 16px; outline: none; }
    textarea:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(92,104,255,.13); }
    .query-actions { margin-top: 14px; display: flex; justify-content: space-between; gap: 16px; align-items: flex-end; }
    .examples { display: flex; flex-wrap: wrap; gap: 8px; }
    .chip, .primary { border: 0; cursor: pointer; font: inherit; }
    .chip { padding: 8px 11px; border-radius: 999px; color: var(--muted); background: var(--surface-2); border: 1px solid var(--border); font-size: 12px; }
    .chip:hover { color: var(--text); border-color: #b9bdf8; }
    .primary { white-space: nowrap; background: var(--accent); color: white; border-radius: 12px; padding: 12px 18px; font-weight: 750; box-shadow: 0 8px 22px rgba(92,104,255,.22); }
    button:disabled { opacity: .55; cursor: not-allowed; }
    @media (max-width: 760px) { .query-card { padding: 22px; } .query-actions { align-items: stretch; flex-direction: column; } .primary { width: 100%; } }
  `]
})
export class QueryPanelComponent {
  @Input() loading = false;
  @Output() runQuery = new EventEmitter<string>();

  prompt = 'Show bugs opened vs closed for the last 6 months';
  examples = [
    'Open issues by priority',
    'Status distribution',
    'Unresolved issues by team'
  ];

  submit(): void {
    const value = this.prompt.trim();
    if (value.length >= 2) this.runQuery.emit(value);
  }

  useExample(example: string): void {
    this.prompt = example;
    this.submit();
  }
}
