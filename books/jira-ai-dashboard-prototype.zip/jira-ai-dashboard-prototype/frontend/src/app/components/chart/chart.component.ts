import { Component, Input } from '@angular/core';
import { ChartWidget } from '../../models/dashboard';

@Component({
  selector: 'app-chart',
  standalone: true,
  template: `
    @if (chart.chart_type === 'bar') {
      <div class="bar-chart">
        @for (category of chart.categories; track category; let i = $index) {
          <div class="bar-row">
            <span class="label">{{ category }}</span>
            <div class="bar-track">
              <div class="bar-fill" [style.width.%]="barPercent(i)"></div>
            </div>
            <strong>{{ chart.series[0].data[i] }}</strong>
          </div>
        }
      </div>
    } @else if (chart.chart_type === 'pie') {
      <div class="pie-layout">
        <div class="donut" [style.background]="pieGradient()">
          <div class="donut-hole">{{ total() }}</div>
        </div>
        <div class="legend">
          @for (category of chart.categories; track category; let i = $index) {
            <div class="legend-row"><span class="dot" [class]="'dot c' + i"></span><span>{{ category }}</span><strong>{{ chart.series[0].data[i] }}</strong></div>
          }
        </div>
      </div>
    } @else {
      <div class="line-wrap">
        <svg viewBox="0 0 620 250" role="img" [attr.aria-label]="chart.title">
          @for (y of [40, 90, 140, 190]; track y) { <line x1="50" [attr.y1]="y" x2="600" [attr.y2]="y" class="grid"/> }
          @for (series of chart.series; track series.name; let s = $index) {
            <polyline [attr.points]="linePoints(series.data)" class="line" [class]="'line line-' + s" fill="none"/>
            @for (value of series.data; track $index; let i = $index) {
              <circle [attr.cx]="x(i)" [attr.cy]="y(value)" r="4" class="point" [class]="'point point-' + s"/>
            }
          }
          @for (category of chart.categories; track category; let i = $index) {
            <text [attr.x]="x(i)" y="230" text-anchor="middle" class="axis-label">{{ category }}</text>
          }
        </svg>
        <div class="series-legend">
          @for (series of chart.series; track series.name; let s = $index) {
            <span><i [class]="'series-mark mark-' + s"></i>{{ series.name }}</span>
          }
        </div>
      </div>
    }
  `,
  styles: [`
    .bar-chart { display: grid; gap: 15px; padding-top: 8px; }
    .bar-row { display: grid; grid-template-columns: minmax(92px, 1fr) 5fr 34px; gap: 12px; align-items: center; font-size: 13px; }
    .label { color: var(--muted); overflow: hidden; text-overflow: ellipsis; }
    .bar-track { background: var(--surface-2); height: 14px; border-radius: 99px; overflow: hidden; }
    .bar-fill { height: 100%; border-radius: inherit; background: linear-gradient(90deg, var(--accent), #9272ff); min-width: 3px; }
    .pie-layout { display: flex; align-items: center; justify-content: center; gap: 42px; padding: 10px 0; }
    .donut { width: 178px; aspect-ratio: 1; border-radius: 50%; display: grid; place-items: center; }
    .donut-hole { width: 92px; aspect-ratio: 1; background: var(--surface); border-radius: 50%; display: grid; place-items: center; font-weight: 800; font-size: 26px; }
    .legend { min-width: 190px; display: grid; gap: 11px; }
    .legend-row { display: grid; grid-template-columns: 12px 1fr auto; align-items: center; gap: 9px; color: var(--muted); }
    .dot { width: 9px; height: 9px; border-radius: 50%; background: var(--accent); }.dot.c1 { background:#9a7af5 }.dot.c2 { background:#d0d3e7 }
    svg { width: 100%; height: auto; overflow: visible; }.grid { stroke: var(--border); stroke-width: 1; }.axis-label { fill: var(--muted); font-size: 12px; }
    .line { stroke: var(--accent); stroke-width: 4; stroke-linecap: round; stroke-linejoin: round; }.line-1 { stroke: #9a7af5; }.point { fill: var(--surface); stroke: var(--accent); stroke-width: 3; }.point-1 { stroke:#9a7af5; }
    .series-legend { display:flex; gap:18px; justify-content:center; color:var(--muted); font-size:13px; }.series-legend span { display:flex; align-items:center; gap:7px; }.series-mark { width:20px; height:3px; border-radius:5px; background:var(--accent); }.mark-1 { background:#9a7af5; }
    @media(max-width:640px){ .pie-layout{flex-direction:column;gap:22px}.bar-row{grid-template-columns:90px 1fr 28px} }
  `]
})
export class ChartComponent {
  @Input({ required: true }) chart!: ChartWidget;

  total(): number { return this.chart.series[0]?.data.reduce((a, b) => a + b, 0) ?? 0; }

  barPercent(index: number): number {
    const values = this.chart.series[0]?.data ?? [];
    const max = Math.max(...values, 1);
    return ((values[index] ?? 0) / max) * 100;
  }

  pieGradient(): string {
    const values = this.chart.series[0]?.data ?? [];
    const total = this.total() || 1;
    const colors = ['#5c68ff', '#9a7af5', '#d0d3e7', '#7a87a8'];
    let cursor = 0;
    const stops = values.map((value, index) => {
      const start = cursor;
      cursor += value / total * 100;
      return `${colors[index % colors.length]} ${start}% ${cursor}%`;
    });
    return `conic-gradient(${stops.join(',')})`;
  }

  x(index: number): number {
    const count = Math.max(this.chart.categories.length - 1, 1);
    return 55 + index * (535 / count);
  }

  y(value: number): number {
    const all = this.chart.series.flatMap(s => s.data);
    const max = Math.max(...all, 1);
    return 200 - (value / max) * 155;
  }

  linePoints(data: number[]): string {
    return data.map((value, i) => `${this.x(i)},${this.y(value)}`).join(' ');
  }
}
