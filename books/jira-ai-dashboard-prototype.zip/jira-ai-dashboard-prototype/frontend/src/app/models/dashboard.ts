export interface MetricWidget {
  type: 'metric';
  title: string;
  value: string | number;
  subtitle?: string | null;
}

export interface Series {
  name: string;
  data: number[];
}

export interface ChartWidget {
  type: 'chart';
  chart_type: 'line' | 'bar' | 'pie';
  title: string;
  categories: string[];
  series: Series[];
}

export interface TableWidget {
  type: 'table';
  title: string;
  columns: string[];
  rows: Array<Array<string | number>>;
}

export interface TextWidget {
  type: 'text';
  title: string;
  body: string;
}

export type Widget = MetricWidget | ChartWidget | TableWidget | TextWidget;

export interface DashboardResponse {
  title: string;
  summary: string;
  source: 'mock' | 'mcp';
  query_used: string;
  widgets: Widget[];
}
