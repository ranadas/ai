import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { DashboardResponse } from '../models/dashboard';

@Injectable({ providedIn: 'root' })
export class AnalyticsService {
  private readonly http = inject(HttpClient);

  query(prompt: string): Observable<DashboardResponse> {
    return this.http.post<DashboardResponse>('/api/query', { prompt });
  }
}
