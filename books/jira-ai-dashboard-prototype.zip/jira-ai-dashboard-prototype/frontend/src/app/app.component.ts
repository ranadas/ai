import { Component, inject } from '@angular/core';
import { finalize } from 'rxjs';
import { QueryPanelComponent } from './components/query-panel/query-panel.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardResponse } from './models/dashboard';
import { AnalyticsService } from './services/analytics.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [QueryPanelComponent, DashboardComponent],
  template: `
    <header class="topbar">
      <div class="brand"><span class="logo">J</span><span>Jira AI Analytics</span></div>
      <span class="prototype">Angular + FastAPI + MCP</span>
    </header>
    <main>
      <app-query-panel [loading]="loading" (runQuery)="run($event)" />
      @if (error) { <div class="error"><strong>Request failed.</strong> {{ error }}</div> }
      @if (dashboard) { <app-dashboard [dashboard]="dashboard" /> }
      @if (!dashboard && !error) {
        <section class="empty-state"><div class="empty-icon">⌁</div><h2>Structured dashboards, not generated HTML</h2><p>Run a query above. The UI renders only supported widget types returned by the Python API.</p></section>
      }
    </main>
  `,
  styles: [`
    .topbar{max-width:1180px;margin:0 auto;padding:22px 24px;display:flex;align-items:center;justify-content:space-between}.brand{display:flex;align-items:center;gap:10px;font-weight:800}.logo{width:32px;height:32px;border-radius:9px;background:var(--accent);color:white;display:grid;place-items:center}.prototype{font-size:12px;color:var(--muted)}main{max-width:1180px;margin:0 auto;padding:14px 24px 60px}.error{margin-top:18px;padding:14px 16px;border:1px solid #efb7b7;background:#fff4f4;border-radius:12px;color:#8d3030}.empty-state{text-align:center;padding:80px 20px;color:var(--muted)}.empty-state h2{color:var(--text);margin:12px 0 7px}.empty-state p{margin:0}.empty-icon{margin:auto;width:52px;height:52px;border-radius:16px;background:var(--surface-2);display:grid;place-items:center;color:var(--accent);font-size:28px}@media(max-width:600px){.prototype{display:none}.topbar,main{padding-left:16px;padding-right:16px}}
  `]
})
export class AppComponent {
  private readonly analytics = inject(AnalyticsService);
  loading = false;
  error = '';
  dashboard: DashboardResponse | null = null;

  run(prompt: string): void {
    this.loading = true;
    this.error = '';
    this.analytics.query(prompt).pipe(finalize(() => this.loading = false)).subscribe({
      next: result => this.dashboard = result,
      error: err => this.error = err?.error?.detail ?? 'Could not reach the backend.'
    });
  }
}
