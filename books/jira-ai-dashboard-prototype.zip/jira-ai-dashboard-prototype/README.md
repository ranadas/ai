# Jira AI Dashboard Prototype

Angular + Python/FastAPI prototype for the pattern:

**Natural-language request -> backend orchestration -> Jira via MCP -> validated dashboard JSON -> Angular rendering**

The project runs out of the box in **mock mode**, so no Jira, MCP server, or AI API key is required to see the full UI flow.

## Architecture

```text
Angular 21 UI
   |
   | POST /api/query
   v
FastAPI backend
   |
   +-- Dashboard service / planner
   |
   +-- JiraProvider
         +-- MockJiraProvider (default)
         +-- McpJiraProvider (Streamable HTTP MCP)
```

The Angular app never renders model-generated HTML. The backend returns a constrained `DashboardResponse` containing metric, chart, table, and text widgets.

## Prerequisites

- Node.js compatible with Angular 21 (Node 20.19+, 22.12+, or 24+)
- Python 3.11+

## Run the backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

The API will be available at `http://localhost:8000`. Swagger UI is at `/docs`.

## Run the Angular UI

In another terminal:

```bash
cd frontend
npm install
npm start
```

Open `http://localhost:4200`.

The Angular dev server proxies `/api/*` to FastAPI on port 8000.

## Try these prompts

- `Show bugs opened vs closed for the last 6 months`
- `Show open issues by priority`
- `Show issue status distribution`
- `Show the top teams with unresolved issues`
- `Show the underlying Jira issues`

## Switch to a real MCP Jira server

The backend uses `JIRA_PROVIDER=mock` by default.

For a Streamable HTTP MCP server:

```bash
export JIRA_PROVIDER=mcp
export MCP_SERVER_URL=http://localhost:9000/mcp
export MCP_JIRA_SEARCH_TOOL=search_jira_issues
uvicorn app.main:app --reload --port 8000
```

`McpJiraProvider` uses the official MCP Python SDK v2 high-level `Client`. The exact tool name and arguments depend on your Jira MCP server. Edit `backend/app/jira_provider.py` method `McpJiraProvider.search_issues()` to map this prototype's normalized query into your server's tool schema.

## Production hardening ideas

- Put authentication/authorization in FastAPI before MCP calls.
- Restrict the MCP client to read-only Jira tools for analytics use cases.
- Add project-level authorization before querying Jira.
- Validate all AI output against Pydantic/JSON Schema.
- Store audit events: user prompt, JQL/tool calls, issue count, response schema version.
- Add caching for repeated analytics queries.
- Replace the simple rule-based planner with an LLM structured-output call while preserving the same schema.
- Use SSE/WebSockets for incremental status and widget streaming.

## API examples

Health:

```bash
curl http://localhost:8000/api/health
```

Query:

```bash
curl -X POST http://localhost:8000/api/query \
  -H 'Content-Type: application/json' \
  -d '{"prompt":"Show bugs opened vs closed for the last 6 months"}'
```

## Tests

```bash
cd backend
pytest
```
